package org.cyclops.clientdevbridge.mcadapter;

import com.mojang.blaze3d.platform.Window;
import net.minecraft.client.Minecraft;
import org.cyclops.clientdevbridge.protocol.RpcException;

/**
 * Resizing the window and setting the GUI scale.
 *
 * This is what makes golden-image comparison possible at all: a screenshot is only comparable to
 * one taken earlier if the framebuffer and the GUI scale are the same, and neither is guaranteed
 * by the launcher alone once a window manager gets involved.
 *
 * @author rubensworks
 */
public class WindowControl {

    /**
     * The smallest window Minecraft will make, which is its own floor rather than one of ours.
     *
     * {@code setWindowed} clamps anything below it, so a smaller request would be accepted here and
     * then quietly ignored -- the caller would be told 200x200 and get 320x240.
     */
    public static final int MIN_WIDTH = Window.MIN_WINDOW_WIDTH;
    public static final int MIN_HEIGHT = Window.MIN_WINDOW_HEIGHT;
    public static final int MAX_SIZE = 7680;

    /**
     * Resizes the window so that its framebuffer is {@code width} x {@code height} pixels.
     *
     * Framebuffer pixels are what every size in the bridge means: screenshots are in them, pixel
     * space is them, and GUI space is them divided by the scale. The window toolkit does not take
     * them. It sizes a window in screen coordinates, and on a display that scales windows -- every
     * Retina Mac, and Windows at anything but 100% -- there are more pixels behind a screen
     * coordinate than one. Passing the request straight through therefore worked only where the
     * two agree: on a doubling display it produced a 1708x960 framebuffer for a request of
     * 854x480, and with it a GUI space, screenshots and pixel coordinates all twice the size the
     * same command produces anywhere else.
     *
     * The window's own two sizes give the factor, and they give the real one -- the pixel density
     * the toolkit reports is what the display asked for, which is not always what the framebuffer
     * ended up at. A display scaling by a fraction can still land a pixel away from the request,
     * because the screen coordinate that maps onto it is not a whole number. The caller is told
     * the size that was reached rather than the one it asked for; the metrics in the result are
     * read from the window afterwards for exactly that reason.
     */
    public static void applySize(int width, int height) {
        if (width < MIN_WIDTH || height < MIN_HEIGHT || width > MAX_SIZE || height > MAX_SIZE) {
            throw RpcException.invalidParams("Window size must be at least " + MIN_WIDTH + "x" + MIN_HEIGHT
                    + " and at most " + MAX_SIZE + " pixels in each dimension, but was " + width + "x" + height);
        }

        Minecraft minecraft = Minecraft.getInstance();
        // Minecraft's own resize rather than the window toolkit's. 26.3 replaced GLFW with SDL, and
        // with it went glfwSetWindowSize; setWindowed is the supported way in, and going through it
        // rather than through SDL directly means the window's bookkeeping -- the windowed size it
        // restores to, the framebuffer size it reports -- is updated with the window instead of
        // drifting out of step with it.
        Window window = minecraft.getWindow();
        window.setWindowed(
                screenCoordinates(width, window.getWidth(), window.getScreenWidth()),
                screenCoordinates(height, window.getHeight(), window.getScreenHeight()));
        // The resize may still be delivered asynchronously; asking Minecraft to re-read it now
        // means the very next frame is already at the new size, rather than one frame later. It
        // does not mean the window reports the new size yet -- see hasResized.
        minecraft.resizeGui();
    }

    /**
     * Converts a framebuffer pixel count into the screen coordinates a window is sized in.
     *
     * @param pixels the framebuffer size being asked for
     * @param currentPixels the framebuffer size now
     * @param currentCoordinates the window size now, in screen coordinates
     */
    private static int screenCoordinates(int pixels, int currentPixels, int currentCoordinates) {
        // A window that has not been mapped yet reports zeroes, and one pixel per coordinate is the
        // right guess when there is nothing to measure: it is what an unscaled display does.
        if (currentPixels <= 0 || currentCoordinates <= 0) {
            return pixels;
        }
        return Math.max(1, Math.round(pixels * (float) currentCoordinates / currentPixels));
    }

    /**
     * Whether the framebuffer has stopped reporting the size it had before {@link #applySize}.
     *
     * The caller has to wait for this before doing anything that depends on the new size. The
     * toolkit's own size callback may not have run when applySize returns, so the window can still
     * report the old dimensions, and it is an edge rather than an exact match that is waited for:
     * on a display that scales by a fraction the framebuffer can settle a pixel away from the
     * request, and waiting for a size it will never report is waiting for the timeout.
     */
    public static boolean hasResized(int previousWidth, int previousHeight) {
        Window window = Minecraft.getInstance().getWindow();
        return window.getWidth() != previousWidth || window.getHeight() != previousHeight;
    }

    /** The framebuffer size, which is the space every size in the protocol is expressed in. */
    public static int[] pixelSize() {
        Window window = Minecraft.getInstance().getWindow();
        return new int[] { window.getWidth(), window.getHeight() };
    }

    /**
     * @param guiScale the fixed GUI scale, or 0 for automatic
     */
    public static void applyGuiScale(int guiScale) {
        Minecraft minecraft = Minecraft.getInstance();
        Window window = minecraft.getWindow();
        // Validated against the window as it is now, which is why the caller has to have waited:
        // the maximum scale is a function of the size, and checking against the old size both
        // rejects scales that just became valid and quotes a limit for a window that is gone.
        int maxScale = window.calculateScale(0, minecraft.isEnforceUnicode());
        if (guiScale < 0 || guiScale > maxScale) {
            // In framebuffer pixels, because that is what calculateScale divides: quoting the
            // window's screen size would name a limit that does not follow from the number beside
            // it on a display that scales windows.
            throw RpcException.invalidParams("GUI scale must be between 0 (auto) and " + maxScale
                    + " at " + window.getWidth() + "x" + window.getHeight()
                    + ", but was " + guiScale);
        }
        minecraft.options.guiScale().set(guiScale);
        minecraft.resizeGui();
    }

}
