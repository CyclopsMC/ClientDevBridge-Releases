package org.cyclops.clientdevbridge.mcadapter;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import org.cyclops.clientdevbridge.protocol.RpcException;

import javax.annotation.Nullable;
import java.util.Locale;
import java.util.Map;

/**
 * Turns the protocol's key names into the codes this Minecraft uses, and, where one exists, the
 * {@link KeyMapping} bound to them.
 *
 * The protocol accepts either a key name ({@code GLFW_KEY_E}, or just {@code E}) or a raw integer,
 * so a caller never has to know Minecraft's own naming.
 *
 * <h2>Why nothing here is a number any more</h2>
 *
 * It used to be: the names were resolved against a hard-coded table of GLFW codes, because that is
 * what every Minecraft up to 26.2 keyed its input on. 26.3 replaced GLFW with SDL, and SDL numbers
 * keys completely differently -- {@code A} is 4 rather than 65, {@code F1} is 58 rather than 290,
 * the left mouse button is 1 rather than 0. A table of the old numbers still compiles and still
 * resolves every name; it just names the wrong keys, silently, forever.
 *
 * So the numbers are gone and the names are resolved through {@link InputConstants#getKey(String)}
 * against Minecraft's own table instead. Minecraft owns the mapping, which means it stays right
 * across a renumbering like this one rather than having to be noticed and rewritten.
 *
 * The protocol's spelling and Minecraft's differ -- {@code LEFT_SHIFT} against
 * {@code key.keyboard.left.shift} -- so the name is converted rather than looked up: upper snake
 * case becomes dotted lower case. That is the whole translation, bar the two keys whose names do
 * not correspond.
 *
 * A raw integer still passes straight through, and on this branch it means an SDL scancode. There
 * is no way to keep that stable across the renumbering, which is the reason to prefer a name.
 *
 * @author rubensworks
 */
public class Keys {

    /** Where Minecraft's keyboard names live; the protocol's names are converted into these. */
    private static final String KEYBOARD_PREFIX = "key.keyboard.";

    /** Where Minecraft's mouse names live. */
    private static final String MOUSE_PREFIX = "key.mouse.";

    /**
     * The two protocol names that are not their Minecraft name in disguise.
     *
     * Everything else -- {@code LEFT_SHIFT}, {@code PAGE_UP}, {@code GRAVE_ACCENT} -- is the dotted
     * lower-case form of the same words. The super key is not: Minecraft calls it the Windows key.
     */
    private static final Map<String, String> ALIASES = Map.of(
            "LEFT_SUPER", "left.win", "RIGHT_SUPER", "right.win");

    /**
     * Modifier bits, as accepted in the protocol's `modifiers` field.
     *
     * Read from Minecraft rather than written down for the same reason as the key codes: SDL's bits
     * are not GLFW's, and shift is 3 here rather than 1.
     */
    public static final int MOD_SHIFT = InputConstants.MOD_SHIFT;
    public static final int MOD_CONTROL = InputConstants.MOD_CONTROL;
    public static final int MOD_ALT = InputConstants.MOD_ALT;

    /**
     * Resolves a key name or code to the keyboard code this Minecraft uses.
     */
    public static int toKeyCode(String raw) {
        return toKeyboardKey(raw).getValue();
    }

    /**
     * Resolves a key name or code to a keyboard key.
     */
    public static InputConstants.Key toKeyboardKey(String raw) {
        String name = raw.trim().toUpperCase(Locale.ROOT);
        try {
            return InputConstants.Type.KEYBOARD.getOrCreate(Integer.parseInt(name));
        } catch (NumberFormatException ignored) {
            // Not a raw code; fall through to the name forms below.
        }
        if (name.startsWith("GLFW_KEY_")) {
            name = name.substring("GLFW_KEY_".length());
        }
        String vanilla = ALIASES.getOrDefault(name, name.toLowerCase(Locale.ROOT).replace('_', '.'));
        try {
            InputConstants.Key key = InputConstants.getKey(KEYBOARD_PREFIX + vanilla);
            if (!key.equals(InputConstants.UNKNOWN)) {
                return key;
            }
        } catch (IllegalArgumentException ignored) {
            // Minecraft does not know the name; report it the way the protocol talks about keys.
        }
        throw RpcException.invalidParams("Unknown key '" + raw + "'. Use a name such as 'GLFW_KEY_E', "
                + "a single letter or digit, 'F3', a named key like 'ESCAPE', a raw integer key code, "
                + "or -- for a held action -- 'ATTACK', 'USE', 'PICK', 'MOUSE_LEFT' or 'HOTBAR_1'.");
    }

    /**
     * Resolves a name to the input the game actually binds, which is not always a keyboard key.
     *
     * {@link #toKeyCode} answers a keyboard code, and attack is bound to {@code key.mouse.left} --
     * so holding attack, which is how every block in the game is mined, could not be expressed at
     * all. Holding use is the same story: eating, drinking, drawing a bow and raising a shield.
     *
     * Three name families are accepted. The action names ({@code ATTACK}, {@code USE},
     * {@code PICK}) are what a caller usually means and say nothing about which button they sit on;
     * the mouse names ({@code MOUSE_LEFT} and friends) address the button directly; and everything
     * else falls through to {@link #toKeyboardKey} as before.
     */
    public static InputConstants.Key toBinding(String raw) {
        String name = raw.trim().toUpperCase(Locale.ROOT);
        Options options = Minecraft.getInstance().options;
        return switch (name) {
            // Through the binding rather than a hard-coded button, so a rebound control still works.
            case "ATTACK", "BREAK", "MINE" -> options.keyAttack.getDefaultKey();
            case "USE", "PLACE" -> options.keyUse.getDefaultKey();
            case "PICK", "PICK_ITEM" -> options.keyPickItem.getDefaultKey();
            // The number row, which selects a hotbar slot. Bound like any other key, but named
            // here because a bare "3" parses as a key code first and never reaches the binding.
            case "HOTBAR_1", "HOTBAR_2", "HOTBAR_3", "HOTBAR_4", "HOTBAR_5",
                 "HOTBAR_6", "HOTBAR_7", "HOTBAR_8", "HOTBAR_9" ->
                    options.keyHotbarSlots[Integer.parseInt(name.substring("HOTBAR_".length())) - 1]
                            .getDefaultKey();
            case "MOUSE_LEFT" -> InputConstants.getKey(MOUSE_PREFIX + "left");
            case "MOUSE_RIGHT" -> InputConstants.getKey(MOUSE_PREFIX + "right");
            case "MOUSE_MIDDLE" -> InputConstants.getKey(MOUSE_PREFIX + "middle");
            default -> toKeyboardKey(raw);
        };
    }

    public static InputConstants.Key toInputKey(int keyCode) {
        return InputConstants.Type.KEYBOARD.getOrCreate(keyCode);
    }

    /**
     * Converts the protocol's mouse button number into the one this Minecraft uses.
     *
     * The protocol numbers buttons the way GLFW did -- 0 left, 1 right, 2 middle -- and that is a
     * wire contract shared with every other branch, so it stays put. SDL numbers them 1 left,
     * 2 middle, 3 right, which is neither the same order nor the same base, so passing the
     * protocol's number through would click the wrong button rather than fail.
     */
    public static int toMouseButton(int protocolButton) {
        return switch (protocolButton) {
            case 0 -> InputConstants.MOUSE_BUTTON_LEFT;
            case 1 -> InputConstants.MOUSE_BUTTON_RIGHT;
            case 2 -> InputConstants.MOUSE_BUTTON_MIDDLE;
            // The extra buttons keep their order and only lose the zero base.
            default -> protocolButton + 1;
        };
    }

    public static InputConstants.Key toMouseKey(int button) {
        return InputConstants.Type.MOUSE.getOrCreate(button);
    }

    /**
     * The vanilla key mapping bound to a key code, when there is one.
     *
     * In-world input has to go through the mapping rather than through a screen, because with no
     * screen open there is no {@code GuiEventListener} to deliver the event to.
     */
    @Nullable
    public static KeyMapping findMapping(int keyCode) {
        return findMapping(toInputKey(keyCode));
    }

    @Nullable
    public static KeyMapping findMapping(InputConstants.Key key) {
        Options options = Minecraft.getInstance().options;
        boolean mouse = key.getType() == InputConstants.Type.MOUSE;
        for (KeyMapping mapping : options.keyMappings) {
            if (mapping.isUnbound()) {
                continue;
            }
            // Keyboard and mouse are separate namespaces -- the left button and the key code that
            // shares its number are not the same input -- so the match has to be made against the
            // right one. Matching only the keyboard is what made every mouse binding unreachable.
            if (mouse
                    ? mapping.matchesMouse(new net.minecraft.client.input.MouseButtonEvent(
                            0, 0, new net.minecraft.client.input.MouseButtonInfo(key.getValue(), 0)))
                    : mapping.matches(new net.minecraft.client.input.KeyEvent(key.getValue(), -1, 0))) {
                return mapping;
            }
        }
        return null;
    }

    /** How a key reads back in an error: the name a caller would have typed. */
    public static String describe(InputConstants.Key key) {
        return key.getType() == InputConstants.Type.MOUSE
                ? "mouse button " + key.getValue()
                : "key code " + key.getValue();
    }

}
