package org.cyclops.clientdevbridge.mcadapter;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import org.cyclops.clientdevbridge.protocol.RpcException;

import javax.annotation.Nullable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Delivering a click to a slot, which is the one version-sensitive step of {@code input.slotClick}.
 *
 * Two things differ across branches and both live here: the enum that names the operation
 * ({@code ClickType} became {@code ContainerInput} in Minecraft 26) and, with it, the signature of
 * the screen method the click goes through.
 *
 * <h2>Through the screen, not the game mode</h2>
 *
 * A real click reaches {@code AbstractContainerScreen.slotClicked} once the screen has worked out
 * which operation was meant, and a screen is allowed to replace that method. This used to call
 * {@code MultiPlayerGameMode} directly instead, which bypasses any such replacement.
 *
 * ColossalChests is the case that made the difference matter. Its menus run to tens of thousands of
 * slots -- a 9x9 chest has 39402 -- and the vanilla container-click packet carries the slot index in
 * a <em>short</em>, so it overrides {@code slotClicked} to send a packet of its own. Calling the
 * game mode reached {@code Shorts.checkedCast} and threw, after the menu had already been mutated:
 * the click landed on the client's copy of the inventory and never reached the server.
 *
 * <h2>Why reflection rather than an access transformer</h2>
 *
 * {@code slotClicked} is {@code protected}, and widening it is not the cheap option it looks like.
 * Access transformers are applied to Minecraft's sources before they are recompiled, so widening a
 * method on a base class leaves every existing override narrowing it -- and vanilla overrides this
 * one five times (the inventory, creative, crafting, crafter and furnace screens). Recompiling then
 * fails outright. Widening all of them as well would mean a list that has to be rediscovered every
 * Minecraft version, in two files, on three branches. One cached {@link Method} is smaller and does
 * not rot.
 *
 * Reflection by name is safe here for the reason the whole mod is: it only ever runs in a
 * development client, where Minecraft carries its real names on both loaders.
 *
 * @author rubensworks
 */
public class SlotInput {

    /**
     * {@code AbstractContainerScreen.slotClicked}, or null if it is not where it was expected.
     *
     * Resolved once, and a failure is carried rather than thrown: a static initialiser that throws
     * takes the whole class down with an {@code ExceptionInInitializerError}, which says far less
     * than the message below.
     */
    @Nullable
    private static final Method SLOT_CLICKED = findSlotClicked();

    @Nullable
    private static Method findSlotClicked() {
        try {
            Method method = AbstractContainerScreen.class.getDeclaredMethod(
                    "slotClicked", Slot.class, int.class, int.class, ClickType.class);
            method.setAccessible(true);
            return method;
        } catch (NoSuchMethodException | RuntimeException e) {
            return null;
        }
    }

    /**
     * Performs a click on a slot, given the protocol's name for what kind of click it is.
     *
     * The slot is passed as well as its index because that is what a real click passes.
     * {@code slotClicked} overwrites the index with {@code slot.index}, and that is the same
     * number: {@code AbstractContainerMenu.addSlot} assigns each slot its position in the menu.
     */
    public static void perform(AbstractContainerScreen<?> screen, Slot slot, int slotId, int button, String type) {
        if (SLOT_CLICKED == null) {
            throw RpcException.illegalState(
                    "AbstractContainerScreen.slotClicked was not found, so a slot click cannot be "
                            + "delivered the way a real click is. This build of the bridge does not "
                            + "match the Minecraft it is running against.");
        }
        try {
            SLOT_CLICKED.invoke(screen, slot, slotId, button, clickType(type));
        } catch (IllegalAccessException e) {
            throw RpcException.illegalState("Could not reach AbstractContainerScreen.slotClicked: " + e);
        } catch (InvocationTargetException e) {
            // Unwrapped rather than passed on wrapped: what the screen threw is the interesting
            // part, and the caller catches it by type.
            Throwable cause = e.getCause();
            if (cause instanceof RuntimeException runtime) {
                throw runtime;
            }
            if (cause instanceof Error error) {
                throw error;
            }
            throw RpcException.illegalState("The screen failed to handle the click: " + cause);
        }
    }

    private static ClickType clickType(String name) {
        return switch (name) {
            case "pickup" -> ClickType.PICKUP;
            case "quick_move" -> ClickType.QUICK_MOVE;
            case "swap" -> ClickType.SWAP;
            case "clone" -> ClickType.CLONE;
            case "throw" -> ClickType.THROW;
            case "quick_craft" -> ClickType.QUICK_CRAFT;
            case "pickup_all" -> ClickType.PICKUP_ALL;
            default -> throw RpcException.invalidParams("Unknown click type '" + name + "'.");
        };
    }

}
