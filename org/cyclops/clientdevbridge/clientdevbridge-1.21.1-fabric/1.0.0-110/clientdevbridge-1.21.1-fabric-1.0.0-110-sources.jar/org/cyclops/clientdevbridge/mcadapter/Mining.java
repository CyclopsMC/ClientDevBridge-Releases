package org.cyclops.clientdevbridge.mcadapter;

import com.google.gson.JsonArray;
import net.minecraft.class_1542;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_310;
import org.cyclops.clientdevbridge.protocol.Json;

/**
 * Breaking a block, the way a player does: by holding attack until the block gives way.
 *
 * A single click does nothing -- mining is a held action, and how long it takes is a function of
 * the block, the tool, and whether the tool is the right one at all. That is exactly the thing a
 * caller should not have to know, and exactly what makes the wait worth measuring: the tick count
 * is the observable difference between the right tool and the wrong one.
 *
 * The progress is advanced <em>once per tick</em> and not in a loop. Calling
 * {@code continueDestroyBlock} repeatedly inside one tick does break the block -- an integrated
 * server validates loosely enough to accept it -- but it is not mining, it makes the tool
 * irrelevant, and a server that checks would refuse it.
 *
 * @author rubensworks
 */
public class Mining {

    public static void start(Aim aim) {
        class_310.method_1551().field_1761.method_2910(aim.pos(), aim.face());
    }

    /** One tick's worth of progress. Answers whether the block has gone. */
    public static boolean advance(Aim aim) {
        class_310 minecraft = class_310.method_1551();
        if (isBroken(aim.pos())) {
            return true;
        }
        minecraft.field_1761.method_2902(aim.pos(), aim.face());
        // The player swings while mining, and a screenshot taken mid-break should show that rather
        // than a player standing still with a block crumbling in front of them.
        minecraft.field_1724.method_6104(net.minecraft.class_1268.field_5808);
        return isBroken(aim.pos());
    }

    public static void stop() {
        class_310.method_1551().field_1761.method_2925();
    }

    public static boolean isBroken(class_2338 pos) {
        return ClientState.requireLevel().method_8320(pos).method_26215();
    }

    /**
     * What is lying on the ground near a position.
     *
     * The point of breaking a block in survival is usually the drop, and the drop is a server-side
     * entity that arrives a moment after the block goes -- so it is worth reporting rather than
     * leaving the caller to go looking for it.
     */
    public static JsonArray dropsNear(class_2338 pos) {
        JsonArray drops = new JsonArray();
        // Wide enough for a drop that bounced: they are thrown, not placed.
        class_238 around = new class_238(pos).method_1014(4.0d);
        for (class_1542 entity : ClientState.requireLevel()
                .method_18467(class_1542.class, around)) {
            com.google.gson.JsonObject drop = Json.object();
            drop.addProperty("item", net.minecraft.class_7923.field_41178
                    .method_10221(entity.method_6983().method_7909()).toString());
            drop.addProperty("count", entity.method_6983().method_7947());
            // Where it actually landed, which is not where the block was: a drop is thrown with a
            // small random velocity and settles a block or two away. Without this a caller has
            // nowhere to walk to in order to pick it up.
            drop.add("pos", Json.arrayOfNumbers(entity.method_23317(), entity.method_23318(), entity.method_23321()));
            drops.add(drop);
        }
        return drops;
    }

}
