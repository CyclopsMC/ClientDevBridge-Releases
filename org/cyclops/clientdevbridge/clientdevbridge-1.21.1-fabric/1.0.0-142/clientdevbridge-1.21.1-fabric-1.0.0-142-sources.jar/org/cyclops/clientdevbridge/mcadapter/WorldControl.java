package org.cyclops.clientdevbridge.mcadapter;

import org.cyclops.clientdevbridge.ClientDevBridge;
import org.cyclops.clientdevbridge.protocol.RpcException;

import javax.annotation.Nullable;
import net.minecraft.class_1267;
import net.minecraft.class_1928;
import net.minecraft.class_1934;
import net.minecraft.class_1940;
import net.minecraft.class_310;
import net.minecraft.class_32;
import net.minecraft.class_5285;
import net.minecraft.class_5317;
import net.minecraft.class_5455;
import net.minecraft.class_7712;
import net.minecraft.class_7924;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

/**
 * Creating, loading, deleting and leaving singleplayer worlds.
 *
 * A world is always created <em>programmatically</em>, through Minecraft's own world-creation code,
 * rather than by shipping a save file. A save file is written in the save format of one particular
 * Minecraft version, so it would silently rot on every branch; going through {@code WorldOpenFlows}
 * is correct for whatever version this branch is built against, by construction.
 *
 * @author rubensworks
 */
public class WorldControl {

    /** A fixed seed, so a reset world is byte-for-byte the same one every time. */
    public static final long SEED = 4_815_162_342L;

    /**
     * The rules that make a test world hold still: no day/night, no weather, no mobs, no drops
     * disappearing, and no advancement toasts drifting across a screenshot.
     */
    private static final List<String> DETERMINISM_GAMERULES = List.of(
            "doDaylightCycle false",
            "doWeatherCycle false",
            "doMobSpawning false",
            "doFireTick false",
            "randomTickSpeed 0",
            "mobGriefing false",
            "doTraderSpawning false",
            "doPatrolSpawning false",
            "announceAdvancements false",
            "sendCommandFeedback true",
            "doInsomnia false",
            "playersSleepingPercentage 200");

    public static final int SPAWN_X = 0;
    public static final int SPAWN_Y = 4;
    public static final int SPAWN_Z = 0;

    /**
     * Half-width of the stone platform built under the spawn.
     *
     * The FLAT preset's surface is far below the documented spawn of 0,4,0, so without a platform
     * the player is spawned into open air and falls — which quietly breaks anything that depends
     * on standing still, most visibly a container screen closing as the player drops out of range.
     * Building the platform keeps the spawn at the documented, easy-to-reason-about coordinates
     * and gives screenshots a uniform backdrop.
     */
    public static final int PLATFORM_RADIUS = 8;
    public static final int PLATFORM_Y = SPAWN_Y - 1;

    public static class_32 levelSource() {
        return class_310.method_1551().method_1586();
    }

    public static boolean exists(String name) {
        return levelSource().method_230(name);
    }

    public static List<String> listWorlds() {
        try (var stream = Files.list(levelSource().method_19636())) {
            return stream
                    .filter(Files::isDirectory)
                    .map(path -> path.getFileName().toString())
                    .sorted(Comparator.naturalOrder())
                    .toList();
        } catch (IOException e) {
            throw RpcException.illegalState("Could not list the saves directory: " + e.getMessage());
        }
    }

    /**
     * Leaves the current world, if any, and waits for the client to actually be out of it.
     */
    public static void leave() {
        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1687 != null) {
            minecraft.field_1687.method_8525();
        }
        minecraft.method_18099();
        minecraft.method_1507(null);
    }

    /**
     * Deletes a save directory. The world must not be loaded.
     */
    public static void delete(String name) {
        if (!exists(name)) {
            return;
        }
        try (class_32.class_5143 access = levelSource().method_27002(name)) {
            access.method_27015();
        } catch (IOException e) {
            throw RpcException.illegalState("Could not delete the world '" + name + "': " + e.getMessage());
        }
    }

    /**
     * Copies a template directory committed in the consumer repository into the saves directory.
     *
     * @param templatesRoot {@code <projectDir>/clientdevbridge/templates}
     */
    /**
     * Checks a template exists before anything is destroyed on its behalf.
     *
     * Splitting this out of {@link #copyTemplate} is the whole point: world.reset leaves the world
     * and deletes it before it copies, so a typo'd template name used to cost the caller the world
     * they had and leave them at the title screen with nothing.
     */
    public static void requireTemplate(Path templatesRoot, String template) {
        Path source = templatesRoot.resolve(template);
        if (!Files.isDirectory(source)) {
            throw RpcException.invalidParams("No world template '" + template + "' at " + source
                    + ". Commit one there, or drop --template to generate a fresh superflat world.");
        }
    }

    public static void copyTemplate(Path templatesRoot, String template, String worldName) {
        requireTemplate(templatesRoot, template);
        Path source = templatesRoot.resolve(template);
        Path target = levelSource().method_52238(worldName);
        try {
            copyRecursively(source, target);
        } catch (IOException e) {
            throw RpcException.illegalState("Could not copy the world template '" + template + "': " + e.getMessage());
        }
    }

    private static void copyRecursively(Path source, Path target) throws IOException {
        try (var stream = Files.walk(source)) {
            for (Path path : stream.toList()) {
                Path destination = target.resolve(source.relativize(path).toString());
                if (Files.isDirectory(path)) {
                    Files.createDirectories(destination);
                } else {
                    Files.createDirectories(destination.getParent());
                    Files.copy(path, destination);
                }
            }
        }
    }

    /**
     * Creates a fresh creative superflat world and starts loading it.
     *
     * This returns as soon as loading has been kicked off; callers wait for the {@code world.joined}
     * condition rather than blocking the client thread.
     */
    public static void createSuperflat(String name) {
        class_310 minecraft = class_310.method_1551();
        class_1940 settings = new class_1940(
                name,
                class_1934.field_9220,
                false,
                class_1267.field_5801,
                true, // Cheats on: everything the bridge does with the world goes through commands.
                new class_1928(),
                class_7712.field_40260);
        class_5285 options = new class_5285(SEED, false, false);

        minecraft.method_41735().method_41895(
                name,
                settings,
                options,
                WorldControl::flatDimensions,
                null);
    }

    private static net.minecraft.class_7723 flatDimensions(class_5455 registryAccess) {
        return registryAccess
                .method_30530(class_7924.field_41250)
                .method_40290(class_5317.field_25054)
                .comp_349()
                .method_45546();
    }

    /**
     * Fails with the list of real world names if this one does not exist.
     */
    public static void requireExists(String name) {
        if (!exists(name)) {
            java.util.List<String> worlds = listWorlds();
            throw RpcException.invalidParams("There is no world called '" + name + "'. "
                    + (worlds.isEmpty()
                            ? "This run directory has no worlds at all yet; make one with "
                                    + "'clientdevbridge world-reset'."
                            : "Existing worlds: " + String.join(", ", worlds)));
        }
    }

    public static void load(String name) {
        requireExists(name);
        class_310.method_1551().method_41735().method_57784(name, () ->
                ClientDevBridge.LOGGER.warn("Failed to open world {}", name));
    }

    /**
     * Applies the determinism game rules and puts the player at a known spot.
     * Run once the world has finished loading.
     */
    public static void applyDeterminism(@Nullable String extraSetup) {
        // Checked, not fire-and-forget. Minecraft 26 renamed every game rule -- camelCase became
        // snake_case, and announceAdvancements became show_advancement_messages -- so this whole
        // list failed silently on those branches for their entire life: the test world kept its
        // day/night cycle, its weather and its random ticks, and golden images passed on luck.
        // A rule that does not apply is a broken test world, so it is worth the whole reset.
        for (String rule : DETERMINISM_GAMERULES) {
            CommandRunner.runChecked("gamerule " + rule);
        }
        CommandRunner.run("time set noon");
        CommandRunner.run("weather clear");
        CommandRunner.run("gamemode creative @s");
        CommandRunner.run(String.format("fill %d %d %d %d %d %d minecraft:stone",
                SPAWN_X - PLATFORM_RADIUS, PLATFORM_Y, SPAWN_Z - PLATFORM_RADIUS,
                SPAWN_X + PLATFORM_RADIUS, PLATFORM_Y, SPAWN_Z + PLATFORM_RADIUS));
        CommandRunner.run(String.format("setworldspawn %d %d %d", SPAWN_X, SPAWN_Y, SPAWN_Z));
        CommandRunner.run("tp @s " + SPAWN_X + " " + SPAWN_Y + " " + SPAWN_Z + " 0 0");
        if (extraSetup != null && !extraSetup.isBlank()) {
            CommandRunner.run(extraSetup);
        }
    }

}
