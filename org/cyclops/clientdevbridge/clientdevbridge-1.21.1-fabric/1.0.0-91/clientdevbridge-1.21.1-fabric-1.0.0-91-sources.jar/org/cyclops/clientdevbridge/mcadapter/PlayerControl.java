package org.cyclops.clientdevbridge.mcadapter;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.cyclops.clientdevbridge.protocol.Json;
import org.cyclops.clientdevbridge.protocol.RpcException;

/**
 * Moving and inspecting the player.
 *
 * Teleporting goes through the integrated server's {@code /tp}, so the server's authoritative
 * position moves with the client's; setting the client position alone would be rubber-banded back.
 *
 * @author rubensworks
 */
public class PlayerControl {

    /**
     * A standing player's eye height. Only used to place the player so that their <em>eyes</em>
     * end up where an aim wants them, which a teleport cannot express directly because it moves
     * the feet.
     */
    public static final double EYE_HEIGHT = 1.62d;

    public static void look(float yaw, float pitch) {
        class_746 player = ClientState.requirePlayer();
        player.method_36456(yaw);
        player.method_36457(Math.max(-90f, Math.min(90f, pitch)));
        player.field_5982 = yaw;
        player.field_6004 = player.method_36455();
        player.method_5847(yaw);
    }

    public static void lookAt(class_243 target) {
        class_746 player = ClientState.requirePlayer();
        class_243 eye = player.method_33571();
        double dx = target.field_1352 - eye.field_1352;
        double dy = target.field_1351 - eye.field_1351;
        double dz = target.field_1350 - eye.field_1350;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0d);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        look(yaw, pitch);
    }

    public static void teleport(double x, double y, double z, Float yaw, Float pitch) {
        String rotation = yaw == null && pitch == null
                ? ""
                : String.format(" %.2f %.2f", yaw == null ? 0f : yaw, pitch == null ? 0f : pitch);
        CommandRunner.run(String.format("tp @s %.4f %.4f %.4f%s", x, y, z, rotation));
        if (yaw != null || pitch != null) {
            look(yaw == null ? ClientState.requirePlayer().method_36454() : yaw,
                    pitch == null ? ClientState.requirePlayer().method_36455() : pitch);
        }
    }

    /**
     * Whether the client-side player has actually arrived within half a block of a target.
     *
     * Half a block is deliberately loose: the server snaps the player onto the ground, so an exact
     * comparison would never be true for a y that is not already resting on a surface.
     */
    public static boolean isAt(double x, double y, double z) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null) {
            return false;
        }
        return Math.abs(player.method_23317() - x) < 0.5d
                && Math.abs(player.method_23318() - y) < 1.5d
                && Math.abs(player.method_23321() - z) < 0.5d;
    }

    /**
     * Whether the player has arrived <em>and stopped moving</em>.
     *
     * {@link #isAt} answers true the moment a teleport lands, which for a target in the air is
     * while the player is still falling: the reply then describes a position they hold for one more
     * tick, and every screenshot after it is of somewhere else. This is the condition a caller who
     * wants a stable camera is actually waiting for.
     *
     * Deliberately not folded into {@code isAt}. {@link Interaction#approach} waits on that one, and
     * {@link Aim#standingPosition} puts the player in mid-air on purpose to look down at a block's
     * top face -- requiring solid ground there would hang every downward interaction until the
     * timeout.
     */
    public static boolean isSettledAt(double x, double y, double z) {
        class_746 player = class_310.method_1551().field_1724;
        return player != null && player.method_24828() && isAt(x, y, z);
    }

    /** Whether the player is falling, for a message that has to explain a position going stale. */
    public static boolean isFalling() {
        class_746 player = class_310.method_1551().field_1724;
        return player != null && !player.method_24828();
    }

    public static void selectHotbarSlot(int slot) {
        if (slot < 0 || slot > 8) {
            throw RpcException.invalidParams("Parameter 'slot' must be a hotbar slot 0-8, but was " + slot);
        }
        ClientState.requirePlayer().method_31548().field_7545 = slot;
    }

    public static JsonObject inventory() {
        class_746 player = ClientState.requirePlayer();
        JsonArray slots = new JsonArray();
        for (int index = 0; index < player.method_31548().method_5439(); index++) {
            class_1799 stack = player.method_31548().method_5438(index);
            slots.add(describeStack(index, stack));
        }
        JsonObject result = Json.object();
        result.add("slots", slots);
        result.addProperty("selected", player.method_31548().field_7545);
        result.add("carried", describeStack(-1, player.field_7512.method_34255()));
        return result;
    }

    /**
     * A compact, stable description of one item stack. Empty stacks are reported as empty rather
     * than omitted, so slot indices always line up with what is on screen.
     */
    public static JsonObject describeStack(int index, class_1799 stack) {
        JsonObject object = Json.object();
        if (index >= 0) {
            object.addProperty("index", index);
        }
        if (stack.method_7960()) {
            object.addProperty("item", (String) null);
            object.addProperty("count", 0);
            return object;
        }
        object.addProperty("item", net.minecraft.class_7923.field_41178
                .method_10221(stack.method_7909()).toString());
        object.addProperty("count", stack.method_7947());
        object.addProperty("name", stack.method_7964().getString());
        if (!stack.method_57353().method_57837()) {
            object.addProperty("components", stack.method_57353().toString());
        }
        // Whatever the mod that owns the item says distinguishes one stack from another. The
        // components string above is a toString, which for a mod's own component type is a class
        // name and an identity hash -- so a container item full and empty describe identically
        // without this.
        JsonObject details = Json.object();
        org.cyclops.clientdevbridge.snapshot.ItemExtractors.apply(stack, details);
        if (!details.isEmpty()) {
            object.add("details", details);
        }
        return object;
    }

    public static class_310 minecraft() {
        return class_310.method_1551();
    }

}
