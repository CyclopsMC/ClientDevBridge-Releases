package org.cyclops.clientdevbridge.mcadapter;

import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.cyclops.clientdevbridge.protocol.RpcException;

/**
 * Opening and closing screens.
 *
 * Opening a block's GUI is a real right-click through {@link class_636#method_2896}, so the
 * block's own interaction logic runs and the resulting screen is the one a player would get — not a
 * screen constructed out of band, which would skip whatever the mod does on interaction.
 *
 * @author rubensworks
 */
public class ScreenControl {

    public static void close() {
        class_310.method_1551().method_1507(null);
    }

    /**
     * Right-clicks a block.
     *
     * @param approach when true, teleports the player next to the block and looks at it first.
     *                 The server enforces a reach limit, so without this a distant block simply
     *                 does nothing and the caller is left wondering why.
     */
    public static void openBlock(class_2338 pos, boolean approach) {
        class_310 minecraft = class_310.method_1551();
        class_746 player = ClientState.requirePlayer();
        class_636 gameMode = minecraft.field_1761;
        if (gameMode == null) {
            throw RpcException.illegalState("There is no game mode yet; the world is still loading.");
        }

        class_243 center = class_243.method_24953(pos);
        if (approach) {
            approach(pos);
        } else {
            double distance = player.method_33571().method_1022(center);
            double reach = player.method_55754();
            if (distance > reach) {
                throw RpcException.illegalState(String.format(
                        "The block at %d,%d,%d is %.1f blocks away but the reach limit is %.1f. "
                                + "Teleport closer first, or leave 'approach' enabled.",
                        pos.method_10263(), pos.method_10264(), pos.method_10260(), distance, reach));
            }
        }

        // Aim at the top face's centre: for the vast majority of blocks any face works, and the
        // top face is the one that is reachable from the standing position chosen by approach().
        class_3965 hit = new class_3965(center, class_2350.field_11036, pos, false);
        gameMode.method_2896(ClientState.requirePlayer(), class_1268.field_5808, hit);
    }

    /**
     * How much closer than the reach limit the player has to already be for the teleport to be
     * skipped. Sitting exactly on the limit would make the interaction depend on rounding.
     */
    private static final double REACH_MARGIN = 0.5d;

    /**
     * Puts the player a couple of blocks away from the target and looks straight at it.
     *
     * When the player can already reach the block, nothing is teleported. That is not just an
     * optimisation: a teleport the player does not need is actively harmful, because the server
     * ignores interactions from a client it is still waiting on a teleport confirmation from. The
     * position hardly changes in that case, so waiting for the player to "arrive" returns
     * immediately, the click goes out during the confirmation window, and the server drops it
     * without a word. It is exactly the state a previous {@code screen.open} leaves the player in,
     * which made every repeated call fail.
     *
     * When it does teleport, the caller must wait for the player to arrive before clicking, for
     * the same underlying reason. {@link #approachTarget(class_2338)} is what to wait for.
     *
     * @return whether the player was teleported
     */
    public static boolean approach(class_2338 pos) {
        class_746 player = ClientState.requirePlayer();
        class_243 center = class_243.method_24953(pos);
        PlayerControl.lookAt(center);
        if (player.method_33571().method_1022(center) <= player.method_55754() - REACH_MARGIN) {
            return false;
        }
        double[] target = approachTarget(pos);
        CommandRunner.run(String.format("tp @s %.2f %.2f %.2f 0 30", target[0], target[1], target[2]));
        PlayerControl.lookAt(center);
        return true;
    }

    /**
     * Where {@link #approach(class_2338)} puts the player, so the caller can wait for it to land
     * there instead of guessing how long the round trip takes.
     */
    public static double[] approachTarget(class_2338 pos) {
        return new double[] { pos.method_10263() + 0.5d, pos.method_10264() + 1.0d, pos.method_10260() + 2.5d };
    }

    /**
     * Explains why nothing opened, with the numbers needed to tell the cases apart.
     */
    public static String describeFailedOpen(class_2338 pos) {
        class_746 player = ClientState.requirePlayer();
        double distance = player.method_33571().method_1022(class_243.method_24953(pos));
        String block = net.minecraft.class_7923.field_41175
                .method_10221(ClientState.requireLevel().method_8320(pos).method_26204()).toString();
        String reason = distance > player.method_55754()
                ? "The player ended up %.1f blocks away, past the %.1f reach limit, so the server "
                        + "rejected the click."
                : "The player is %.1f blocks away, inside the %.1f reach limit, so the click was "
                        + "delivered and the block simply opened nothing.";
        return String.format(
                "Right-clicking %s at %s opened no screen. " + reason
                        + " Blocks without a GUI do nothing here, which is expected; if this one "
                        + "should have opened something, check 'clientdevbridge block %d %d %d'.",
                block, pos.method_23854(), distance, player.method_55754(),
                pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

}
