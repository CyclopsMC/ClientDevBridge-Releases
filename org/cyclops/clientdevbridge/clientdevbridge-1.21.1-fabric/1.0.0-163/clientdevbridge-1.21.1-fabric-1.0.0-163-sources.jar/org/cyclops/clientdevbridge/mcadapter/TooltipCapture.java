package org.cyclops.clientdevbridge.mcadapter;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.cyclops.clientdevbridge.protocol.Json;

import javax.annotation.Nullable;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_7919;
import java.util.ArrayList;
import java.util.List;

/**
 * Reads the tooltip that would be shown at a point on screen.
 *
 * Two sources cover essentially every tooltip a mod author cares about, and both can be read
 * directly rather than intercepted:
 *
 * <ul>
 *     <li>the item under the cursor in a container screen, through the same
 *     {@code getTooltipFromItem} the screen itself uses;</li>
 *     <li>the {@link class_7919} attached to the hovered widget.</li>
 * </ul>
 *
 * A screen that draws a tooltip ad hoc inside its own {@code render} — rather than attaching one or
 * relying on a slot — is not visible here. Capturing those would mean mixing into
 * {@code GuiGraphics#renderTooltipInternal}, a private method whose argument type
 * ({@code ClientTooltipComponent}) does not expose its text; that is a lot of fragility across
 * versions for a case that a `screenshot` already shows. If you need it, register a
 * {@code SnapshotExtractor} for your screen's widget and put the text in {@code extra}.
 *
 * @author rubensworks
 */
public class TooltipCapture {

    /**
     * Describes the tooltip at a GUI-space point, moving the mouse there first so that hover state
     * matches what the caller asked about.
     */
    public static JsonObject at(double x, double y) {
        InputControl.mouseMove(x, y);

        JsonObject result = Json.object();
        result.add("at", Json.arrayOfNumbers(x, y));

        class_437 screen = ClientState.screen();
        if (screen == null) {
            result.add("lines", new JsonArray());
            result.addProperty("source", "none");
            return result;
        }

        if (screen instanceof class_465<?> container) {
            class_1735 slot = slotAt(container, x, y);
            if (slot != null && !slot.method_7677().method_7960()) {
                result.add("lines", linesOf(itemTooltip(slot.method_7677())));
                result.addProperty("source", "slot");
                result.addProperty("slot", slot.field_7874);
                result.add("item", PlayerControl.describeStack(slot.field_7874, slot.method_7677()));
                return result;
            }
        }

        class_339 widget = widgetAt(screen, x, y);
        if (widget != null && widget.method_51254() != null) {
            result.add("lines", describe(widget.method_51254()));
            result.addProperty("source", "widget");
            result.addProperty("widget", widget.getClass().getName());
            result.addProperty("message", widget.method_25369() == null ? null : widget.method_25369().getString());
            return result;
        }

        // Three quite different situations used to answer "none" alike, and the third is the one
        // that misleads: a tooltip a mod paints in its own render is not attached to anything the
        // game models, so nothing here can reach it -- and reporting that as "no tooltip" says the
        // opposite of what a screenshot of the same point shows.
        result.add("lines", new JsonArray());
        if (widget != null) {
            result.addProperty("source", "widgetWithoutTooltip");
            result.addProperty("widget", widget.getClass().getName());
            result.addProperty("note", "There is a widget here and it has no tooltip attached.");
        } else {
            result.addProperty("source", "unmodelled");
            result.addProperty("note", "Nothing here is a widget or a slot, so there is no tooltip "
                    + "to read -- but a mod that paints its own tooltip in render() draws one "
                    + "without registering anything, and that cannot be read from here. Take a "
                    + "screenshot with the cursor parked at this point to see whether one is drawn.");
        }
        return result;
    }

    /**
     * The lines of an attached widget tooltip.
     */
    public static JsonArray describe(class_7919 tooltip) {
        JsonArray lines = new JsonArray();
        for (net.minecraft.class_5481 sequence : tooltip.method_47405(class_310.method_1551())) {
            lines.add(flatten(sequence));
        }
        return lines;
    }

    private static String flatten(net.minecraft.class_5481 sequence) {
        StringBuilder builder = new StringBuilder();
        sequence.accept((index, style, codePoint) -> {
            builder.appendCodePoint(codePoint);
            return true;
        });
        return builder.toString();
    }

    private static List<class_2561> itemTooltip(class_1799 stack) {
        return class_437.method_25408(class_310.method_1551(), stack);
    }

    private static JsonArray linesOf(List<class_2561> components) {
        JsonArray lines = new JsonArray();
        for (class_2561 component : components) {
            lines.add(component.getString());
        }
        return lines;
    }

    @Nullable
    private static class_1735 slotAt(class_465<?> screen, double x, double y) {
        for (class_1735 slot : screen.method_17577().field_7761) {
            double slotX = screen.field_2776 + slot.field_7873;
            double slotY = screen.field_2800 + slot.field_7872;
            if (x >= slotX && x < slotX + 16 && y >= slotY && y < slotY + 16 && slot.method_7682()) {
                return slot;
            }
        }
        return null;
    }

    /**
     * The deepest widget whose bounds contain the point, so a widget nested inside a list wins over
     * the list itself.
     */
    @Nullable
    public static class_339 widgetAt(class_437 screen, double x, double y) {
        List<class_339> matches = new ArrayList<>();
        collect(screen.method_25396(), x, y, matches, 0);
        return matches.isEmpty() ? null : matches.get(matches.size() - 1);
    }

    private static void collect(List<? extends class_364> children, double x, double y,
                                List<class_339> matches, int depth) {
        if (depth > WidgetWalker.MAX_DEPTH) {
            return;
        }
        for (class_364 child : children) {
            if (child instanceof class_339 widget && widget.field_22764 && widget.method_25405(x, y)) {
                matches.add(widget);
            }
            if (child instanceof class_4069 container) {
                collect(container.method_25396(), x, y, matches, depth + 1);
            }
        }
    }

}
