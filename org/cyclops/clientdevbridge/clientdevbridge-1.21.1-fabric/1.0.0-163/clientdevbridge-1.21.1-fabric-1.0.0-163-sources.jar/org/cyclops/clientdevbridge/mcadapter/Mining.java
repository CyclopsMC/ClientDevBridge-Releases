package org.cyclops.clientdevbridge.mcadapter;

import com.google.gson.JsonArray;
import net.minecraft.class_1542;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_310;
import org.cyclops.clientdevbridge.protocol.Json;

/**
 * Breaking a block, the way a player does: by holding attack until the block gives way.
 *
 * A single click does nothing -- mining is a held action, and how long it takes is a function of
 * the block, the tool, and whether the tool is the right one at all. That is exactly the thing a
 * caller should not have to know, and exactly what makes the wait worth measuring: the tick count
 * is the observable difference between the right tool and the wrong one.
 *
 * The progress is advanced <em>once per tick</em> and not in a loop. Calling
 * {@code continueDestroyBlock} repeatedly inside one tick does break the block -- an integrated
 * server validates loosely enough to accept it -- but it is not mining, it makes the tool
 * irrelevant, and a server that checks would refuse it.
 *
 * @author rubensworks
 */
public class Mining {

    public static void start(Aim aim) {
        class_310.method_1551().field_1761.method_2910(aim.pos(), aim.face());
    }

    /** One tick's worth of progress. Answers whether the block has gone. */
    public static boolean advance(Aim aim) {
        class_310 minecraft = class_310.method_1551();
        if (isBroken(aim.pos())) {
            return true;
        }
        minecraft.field_1761.method_2902(aim.pos(), aim.face());
        // The player swings while mining, and a screenshot taken mid-break should show that rather
        // than a player standing still with a block crumbling in front of them.
        minecraft.field_1724.method_6104(net.minecraft.class_1268.field_5808);
        return isBroken(aim.pos());
    }

    public static void stop() {
        class_310.method_1551().field_1761.method_2925();
    }

    public static boolean isBroken(class_2338 pos) {
        return ClientState.requireLevel().method_8320(pos).method_26215();
    }

    /**
     * What is lying on the ground near a position.
     *
     * The point of breaking a block in survival is usually the drop, and the drop is a server-side
     * entity that arrives a moment after the block goes -- so it is worth reporting rather than
     * leaving the caller to go looking for it.
     */
    /**
     * The item entities lying near a block, by entity id.
     *
     * Taken before a break so that {@link #dropsNear} can tell what the break produced from what
     * was already on the ground. Without it, breaking a block in creative -- where nothing can drop
     * at all -- still reported "dropped" whatever happened to be lying within four blocks, which on
     * a world whose player starts with an item on the floor is a drop that never existed.
     */
    public static java.util.Set<Integer> itemEntitiesNear(class_2338 pos) {
        java.util.Set<Integer> ids = new java.util.HashSet<>();
        for (class_1542 entity : ClientState.requireLevel()
                .method_18467(class_1542.class, searchArea(pos))) {
            ids.add(entity.method_5628());
        }
        return ids;
    }

    /** Wide enough for a drop that bounced: they are thrown, not placed. */
    private static class_238 searchArea(class_2338 pos) {
        return new class_238(pos).method_1014(4.0d);
    }

    public static JsonArray dropsNear(class_2338 pos, java.util.Set<Integer> before) {
        JsonArray drops = new JsonArray();
        for (class_1542 entity : ClientState.requireLevel()
                .method_18467(class_1542.class, searchArea(pos))) {
            // Only what appeared. An entity that was already there is not this break's doing.
            if (before.contains(entity.method_5628())) {
                continue;
            }
            com.google.gson.JsonObject drop = Json.object();
            drop.addProperty("item", itemId(entity.method_6983()));
            drop.addProperty("count", entity.method_6983().method_7947());
            // Where it actually landed, which is not where the block was: a drop is thrown with a
            // small random velocity and settles a block or two away. Without this a caller has
            // nowhere to walk to in order to pick it up.
            drop.add("pos", Json.arrayOfNumbers(entity.method_23317(), entity.method_23318(), entity.method_23321()));
            drops.add(drop);
        }
        return drops;
    }

    /**
     * How many of each item the player is carrying, keyed by item id.
     *
     * The companion to {@link #dropsNear}, and it exists because that one only sees what is still
     * lying on the ground. A vanilla drop can be picked up ten ticks after it spawns, which is
     * exactly the settle this waits out -- so a player standing near the block collects it on the
     * very tick the search runs, and a break that dropped something reported dropping nothing. It
     * only ever went wrong when the timing was tight, which meant it went wrong on CI and not here.
     */
    public static java.util.Map<String, Integer> carrying() {
        java.util.Map<String, Integer> counts = new java.util.HashMap<>();
        var inventory = ClientState.requirePlayer().method_31548();
        for (int index = 0; index < inventory.method_5439(); index++) {
            class_1799 stack = inventory.method_5438(index);
            if (!stack.method_7960()) {
                counts.merge(itemId(stack), stack.method_7947(), Integer::sum);
            }
        }
        return counts;
    }

    /**
     * What the player has gained since {@code before}, in the same shape as {@link #dropsNear}
     * minus the position -- a collected item is no longer anywhere to walk to.
     */
    public static JsonArray collectedSince(java.util.Map<String, Integer> before) {
        JsonArray collected = new JsonArray();
        java.util.Map<String, Integer> now = carrying();
        java.util.List<String> ids = new java.util.ArrayList<>(now.keySet());
        java.util.Collections.sort(ids);
        for (String id : ids) {
            int gained = now.get(id) - before.getOrDefault(id, 0);
            if (gained > 0) {
                com.google.gson.JsonObject entry = Json.object();
                entry.addProperty("item", id);
                entry.addProperty("count", gained);
                collected.add(entry);
            }
        }
        return collected;
    }

    private static String itemId(class_1799 stack) {
        return net.minecraft.class_7923.field_41178.method_10221(stack.method_7909()).toString();
    }

}
