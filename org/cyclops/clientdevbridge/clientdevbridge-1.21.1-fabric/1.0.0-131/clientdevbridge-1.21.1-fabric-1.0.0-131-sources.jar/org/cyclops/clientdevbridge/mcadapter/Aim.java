package org.cyclops.clientdevbridge.mcadapter;

import org.cyclops.clientdevbridge.ClientDevBridge;
import org.cyclops.clientdevbridge.protocol.RpcException;

import javax.annotation.Nullable;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3965;

/**
 * Where on a block an interaction is aimed.
 *
 * A vanilla block reads the {@link class_3965} it is handed, so any face works and aiming was
 * never worth expressing. Multipart blocks do not: Integrated Dynamics' cables, and anything else
 * built on CyclopsCore's {@code VoxelShapeComponents}, throw the hit result away and re-raytrace
 * from the player's eye along their look angle to decide which sub-part was clicked. For those,
 * <em>where the player stands and looks</em> is the whole interaction, and a caller that cannot
 * say which side of a cable it means cannot open a part's GUI at all.
 *
 * So an aim carries both halves and keeps them consistent: the point that goes into the hit result,
 * and the position to stand in for the ray from the eye to that point to arrive through the
 * intended face.
 *
 * @author rubensworks
 */
public class Aim {

    /** How far from the aimed point to stand. Comfortably inside the default reach limit. */
    private static final double STANDING_DISTANCE = 2.5d;

    private final class_2338 pos;
    private final class_2350 face;
    private final class_243 point;

    private Aim(class_2338 pos, class_2350 face, class_243 point) {
        this.pos = pos;
        this.face = face;
        this.point = point;
    }

    /**
     * Resolves an aim from what a caller supplied, in plain types so the protocol layer never has
     * to name a Minecraft class.
     *
     * @param face  a face name, or null
     * @param at    a world-space point, or null
     */
    public static Aim of(class_2338 pos, @Nullable String face, @Nullable double[] at) {
        class_2350 direction = face == null ? null : parseFace(face);
        if (at != null) {
            class_243 point = new class_243(at[0], at[1], at[2]);
            return new Aim(pos, direction == null ? nearestFace(pos, point) : direction, point);
        }
        if (direction != null) {
            return new Aim(pos, direction, faceCentre(pos, direction));
        }
        // No aim given: the block's centre, as it always was. Every vanilla block behaves the same
        // whichever face it is handed, so this stays the right default.
        return new Aim(pos, class_2350.field_11036, class_243.method_24953(pos));
    }

    public class_2338 pos() {
        return this.pos;
    }

    public class_2350 face() {
        return this.face;
    }

    public class_243 point() {
        return this.point;
    }

    /** Whether the caller asked for a particular spot, rather than taking the default. */
    public boolean isDirected() {
        return !this.point.equals(class_243.method_24953(this.pos));
    }

    public class_3965 hit() {
        return new class_3965(this.point, this.face, this.pos, false);
    }

    /**
     * Where the player has to stand for the aimed point to be reachable and, more importantly, for
     * the ray from their eye to reach it through {@link #face()} rather than through the block.
     *
     * The eye has to end up outside the aimed face, so the position depends on which face it is.
     * It also has to be somewhere the player can stand: teleporting to a point in mid-air means
     * they start falling immediately, which moves the eye out from under the aim before the click
     * and stops the arrival wait from ever seeing them land.
     *
     * <ul>
     *   <li>A side face: back off along its normal, standing level with the block's bottom.</li>
     *   <li>The top face: stand on the block and look straight down. A ray that comes in at an
     *       angle carries on through the block and out the far side, where it can clip a part on
     *       another face -- so on a cable, asking for the top would open whatever was on the
     *       north.</li>
     *   <li>The bottom face: there is nowhere good. The player has to be under the block, which in
     *       a flat test world is inside the ground -- survivable in creative, and the ray is
     *       unaffected, but a caller that knows its own scene should place the player itself and
     *       pass {@code approach: false}.</li>
     * </ul>
     *
     * @return the feet position, which is what a teleport takes
     */
    public double[] standingPosition() {
        switch (this.face) {
            // Straight above, looking straight down. Standing off to one side and looking across
            // would be a shallow ray, and a shallow ray does not stop at the face it was aimed at:
            // it carries on through the block and out the far side, where it can clip a part on
            // one of the other faces. A vertical ray meets the top face first and the block's
            // centre second, which is the order a caller asking for the top face means.
            case field_11036:
                return new double[] { this.point.field_1352, this.pos.method_10264() + 1.0d, this.point.field_1350 };
            case field_11033:
                return new double[] { this.point.field_1352, this.point.field_1351 - STANDING_DISTANCE - PlayerControl.EYE_HEIGHT,
                        this.point.field_1350 };
            // A side face is looked at from standing height, level with the block's own bottom --
            // where a player walking up to it stands. That is a shallow ray too, but it enters
            // through the aimed face, which is what decides the interaction.
            default:
                return new double[] {
                        this.point.field_1352 + this.face.method_10148() * STANDING_DISTANCE,
                        this.pos.method_10264(),
                        this.point.field_1350 + this.face.method_10165() * STANDING_DISTANCE };
        }
    }

    /**
     * The yaw and pitch that look at this aim from {@link #standingPosition()}.
     *
     * Worked out from the target position rather than measured from the current one, so it can be
     * handed to the teleport itself. Aiming after the teleport is issued but before it lands would
     * compute the angles from wherever the player still is.
     *
     * @return {yaw, pitch} in degrees
     */
    public float[] lookAngles() {
        double[] feet = standingPosition();
        double dx = this.point.field_1352 - feet[0];
        double dy = this.point.field_1351 - (feet[1] + PlayerControl.EYE_HEIGHT);
        double dz = this.point.field_1350 - feet[2];
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        return new float[] {
                (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0d),
                (float) -Math.toDegrees(Math.atan2(dy, horizontal)) };
    }

    /**
     * The centre of a face of the block's <em>actual</em> shape, not of the unit cube.
     *
     * A cable's core runs 6/16 to 10/16, so the centre of the unit cube's west face is empty air: a
     * ray aimed there passes straight through, the interaction lands on nothing, and -- because the
     * click itself was delivered -- it is reported as a success that did nothing. Reading the real
     * shape costs one lookup and makes {@code --face} mean what a caller assumes it means.
     *
     * Falls back to the unit cube when a block has no shape at all, which is what an empty shape
     * used to be treated as anyway.
     */
    private static class_243 faceCentre(class_2338 pos, class_2350 face) {
        class_238 bounds = shapeOf(pos);
        // The two axes across the face take the shape's middle; the axis along it takes the face.
        double x = face.method_10148() == 0
                ? pos.method_10263() + (bounds.field_1323 + bounds.field_1320) / 2
                : pos.method_10263() + (face.method_10148() > 0 ? bounds.field_1320 : bounds.field_1323);
        double y = face.method_10164() == 0
                ? pos.method_10264() + (bounds.field_1322 + bounds.field_1325) / 2
                : pos.method_10264() + (face.method_10164() > 0 ? bounds.field_1325 : bounds.field_1322);
        double z = face.method_10165() == 0
                ? pos.method_10260() + (bounds.field_1321 + bounds.field_1324) / 2
                : pos.method_10260() + (face.method_10165() > 0 ? bounds.field_1324 : bounds.field_1321);
        return new class_243(x, y, z);
    }

    /** The block's collision-independent outline, in block-local coordinates. */
    private static class_238 shapeOf(class_2338 pos) {
        try {
            net.minecraft.class_265 shape = ClientState.requireLevel()
                    .method_8320(pos).method_26218(ClientState.requireLevel(), pos);
            if (!shape.method_1110()) {
                return shape.method_1107();
            }
        } catch (Throwable e) {
            // A shape that cannot be asked for is not worth failing an interaction over; the unit
            // cube is what this always used to assume.
            ClientDevBridge.LOGGER.debug("Could not read the shape at {}, aiming at the full cube", pos, e);
        }
        return new class_238(0, 0, 0, 1, 1, 1);
    }

    /** The face whose plane the point lies closest to, for a caller that gave a point but no face. */
    private static class_2350 nearestFace(class_2338 pos, class_243 point) {
        class_243 offset = point.method_1020(class_243.method_24953(pos));
        class_2350 best = class_2350.field_11036;
        double bestDistance = Double.MAX_VALUE;
        for (class_2350 candidate : class_2350.values()) {
            class_243 centre = faceCentre(pos, candidate).method_1020(class_243.method_24953(pos));
            double distance = offset.method_1022(centre);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = candidate;
            }
        }
        return best;
    }

    private static class_2350 parseFace(String face) {
        class_2350 direction = class_2350.method_10168(face.toLowerCase(java.util.Locale.ROOT));
        if (direction == null) {
            throw RpcException.invalidParams(String.format(
                    "'%s' is not a face. Expected one of: down, up, north, south, east, west.", face));
        }
        return direction;
    }

}
