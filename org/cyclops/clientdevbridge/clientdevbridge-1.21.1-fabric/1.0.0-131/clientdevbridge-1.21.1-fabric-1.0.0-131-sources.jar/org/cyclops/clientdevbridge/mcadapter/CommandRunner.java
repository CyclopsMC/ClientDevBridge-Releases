package org.cyclops.clientdevbridge.mcadapter;

import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.cyclops.clientdevbridge.protocol.RpcException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Runs commands on the integrated server and collects what they printed.
 *
 * Vanilla sends command feedback to the player as chat, which the client would have to scrape.
 * Instead the command is dispatched through a {@link class_2165} that simply appends every
 * message to a list, so the caller gets the exact output the command produced.
 *
 * @author rubensworks
 */
public class CommandRunner {

    /**
     * The outcome of one command.
     *
     * Success is reported separately from the output because a failing command still prints
     * something -- "Unknown block type ..." -- and a caller that only looks at the output cannot
     * tell a built scene from a scene that was never built.
     */
    public record Result(boolean success, int value, List<String> output) {
    }

    /**
     * Runs a command, keeping only its output. Prefer {@link #runChecked} where failure matters.
     */
    public static List<String> run(String command) {
        return execute(command).output();
    }

    /**
     * Runs a command and fails the request if the command itself failed.
     */
    public static Result runChecked(String command) {
        Result result = execute(command);
        if (!result.success()) {
            throw RpcException.illegalState("The command '" + command + "' failed: "
                    + (result.output().isEmpty() ? "no output" : String.join(" ", result.output())));
        }
        return result;
    }

    /**
     * @param command the command, with or without a leading slash
     * @return the command's success flag, result value, and feedback messages in order
     */
    public static Result execute(String command) {
        MinecraftServer server = requireServer();
        String normalised = command.startsWith("/") ? command.substring(1) : command;
        if (normalised.isBlank()) {
            throw RpcException.invalidParams("Parameter 'command' must not be empty.");
        }

        List<String> output = Collections.synchronizedList(new ArrayList<>());
        class_2165 collector = new class_2165() {
            @Override
            public void method_43496(class_2561 component) {
                output.add(component.getString());
            }

            @Override
            public boolean method_9200() {
                return true;
            }

            @Override
            public boolean method_9202() {
                return true;
            }

            @Override
            public boolean method_9201() {
                return false;
            }

            @Override
            public boolean method_36320() {
                return true;
            }
        };

        // Run as the player when there is one, so relative coordinates and selectors behave the way
        // they would if the command had been typed into chat.
        class_2168 source = server.method_3739().method_36321(collector).method_9230(4);
        class_3222 serverPlayer = serverPlayer(server);
        if (serverPlayer != null) {
            source = source.method_9232(serverPlayer)
                    .method_9208(serverPlayer.method_19538())
                    .method_9216(serverPlayer.method_5802())
                    .method_9227(serverPlayer.method_51469());
        }

        // Brigadier reports success through the source's result callback rather than a return
        // value, so this is the only way to learn whether the command actually did anything.
        boolean[] success = { false };
        int[] value = { 0 };
        source = source.method_9231((succeeded, result) -> {
            success[0] = succeeded;
            value[0] = result;
        });

        server.method_3734().method_44252(source, normalised);
        return new Result(success[0], value[0], new ArrayList<>(output));
    }

    public static MinecraftServer requireServer() {
        MinecraftServer server = class_310.method_1551().method_1576();
        if (server == null) {
            throw RpcException.illegalState("There is no integrated server: commands need a singleplayer world. "
                    + "Run 'clientdevbridge world-reset' first.");
        }
        return server;
    }

    private static class_3222 serverPlayer(MinecraftServer server) {
        if (class_310.method_1551().field_1724 == null) {
            return null;
        }
        return server.method_3760().method_14602(class_310.method_1551().field_1724.method_5667());
    }

}
