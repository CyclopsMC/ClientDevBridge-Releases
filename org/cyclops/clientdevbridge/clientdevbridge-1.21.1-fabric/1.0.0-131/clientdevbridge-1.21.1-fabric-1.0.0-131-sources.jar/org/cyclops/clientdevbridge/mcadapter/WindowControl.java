package org.cyclops.clientdevbridge.mcadapter;

import net.minecraft.class_1041;
import net.minecraft.class_310;
import org.cyclops.clientdevbridge.protocol.RpcException;
import org.lwjgl.glfw.GLFW;

/**
 * Resizing the window and setting the GUI scale.
 *
 * This is what makes golden-image comparison possible at all: a screenshot is only comparable to
 * one taken earlier if the framebuffer and the GUI scale are the same, and neither is guaranteed
 * by the launcher alone once a window manager gets involved.
 *
 * @author rubensworks
 */
public class WindowControl {

    public static final int MIN_SIZE = 64;
    public static final int MAX_SIZE = 7680;

    public static void applySize(int width, int height) {
        if (width < MIN_SIZE || height < MIN_SIZE || width > MAX_SIZE || height > MAX_SIZE) {
            throw RpcException.invalidParams("Window size must be between " + MIN_SIZE + " and " + MAX_SIZE
                    + " pixels in each dimension, but was " + width + "x" + height);
        }

        class_310 minecraft = class_310.method_1551();
        GLFW.glfwSetWindowSize(minecraft.method_22683().method_4490(), width, height);
        // GLFW delivers the resize asynchronously; asking Minecraft to re-read it now means the
        // very next frame is already at the new size, rather than one frame later. It does not
        // mean the window reports the new size yet -- see hasResized.
        minecraft.method_15993();
    }

    /**
     * Whether the window has stopped reporting the size it had before {@link #applySize}.
     *
     * The caller has to wait for this before doing anything that depends on the new size. GLFW's
     * own size callback has not run when applySize returns, so the window still reports the old
     * dimensions, and it is an edge rather than an exact match that is waited for: the framebuffer
     * is not required to end up exactly the requested size, and on a scaled display it will not.
     */
    public static boolean hasResized(int previousWidth, int previousHeight) {
        class_1041 window = class_310.method_1551().method_22683();
        return window.method_4480() != previousWidth || window.method_4507() != previousHeight;
    }

    public static int[] screenSize() {
        class_1041 window = class_310.method_1551().method_22683();
        return new int[] { window.method_4480(), window.method_4507() };
    }

    /**
     * @param guiScale the fixed GUI scale, or 0 for automatic
     */
    public static void applyGuiScale(int guiScale) {
        class_310 minecraft = class_310.method_1551();
        class_1041 window = minecraft.method_22683();
        // Validated against the window as it is now, which is why the caller has to have waited:
        // the maximum scale is a function of the size, and checking against the old size both
        // rejects scales that just became valid and quotes a limit for a window that is gone.
        int maxScale = window.method_4476(0, minecraft.method_1573());
        if (guiScale < 0 || guiScale > maxScale) {
            throw RpcException.invalidParams("GUI scale must be between 0 (auto) and " + maxScale
                    + " at " + window.method_4480() + "x" + window.method_4507()
                    + ", but was " + guiScale);
        }
        minecraft.field_1690.method_42474().method_41748(guiScale);
        minecraft.method_15993();
    }

}
