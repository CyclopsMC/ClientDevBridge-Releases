package org.cyclops.clientdevbridge.mcadapter;

import com.google.gson.JsonObject;
import org.cyclops.clientdevbridge.protocol.Json;

import javax.annotation.Nullable;
import net.minecraft.class_310;
import java.util.function.BiConsumer;

/**
 * Turns state changes into protocol notifications.
 *
 * Both loaders have events for screen opening and for joining a world, but they differ in shape and
 * in exactly when they fire. Deriving the transitions from a single per-tick comparison instead
 * keeps the loader surface down to one callback, and gives both loaders identical semantics — which
 * is what the protocol promises.
 *
 * @author rubensworks
 */
public class StateWatcher {

    private final BiConsumer<String, JsonObject> notify;
    private final boolean suppressToasts;

    @Nullable
    private String lastScreenClass;
    private boolean lastInWorld;
    private boolean primed;

    public StateWatcher(BiConsumer<String, JsonObject> notify, boolean suppressToasts) {
        this.notify = notify;
        this.suppressToasts = suppressToasts;
    }

    public void onClientTick() {
        class_310 minecraft = class_310.method_1551();

        // Before anything else: a client parked on the onboarding screen is waiting for a human,
        // and no amount of driving gets past it.
        Onboarding.dismissIfShowing();

        // Toasts fade in and out over several seconds, so anything on screen while one is showing
        // is not reproducible. Clearing them every tick keeps them from ever being drawn.
        if (this.suppressToasts) {
            minecraft.method_1566().method_2000();
        }
        String screenClass = minecraft.field_1755 == null ? null : minecraft.field_1755.getClass().getName();
        boolean inWorld = minecraft.field_1687 != null && minecraft.field_1724 != null;

        if (!this.primed) {
            this.primed = true;
            this.lastScreenClass = screenClass;
            this.lastInWorld = inWorld;
            return;
        }

        if (!java.util.Objects.equals(screenClass, this.lastScreenClass)) {
            JsonObject params = Json.object();
            params.addProperty("screenClass", screenClass);
            params.addProperty("previousScreenClass", this.lastScreenClass);
            if (minecraft.field_1755 != null) {
                params.addProperty("title", minecraft.field_1755.method_25440().getString());
            }
            this.lastScreenClass = screenClass;
            this.notify.accept("screen.changed", params);
        }

        if (inWorld != this.lastInWorld) {
            this.lastInWorld = inWorld;
            JsonObject params = Json.object();
            if (inWorld && minecraft.field_1687 != null) {
                params.addProperty("dimension", minecraft.field_1687.method_27983().method_29177().toString());
            }
            this.notify.accept(inWorld ? "world.joined" : "world.left", params);
            if (!inWorld) {
                // A held movement key must not survive into the next scenario.
                InputControl.releaseAll();
            }
        }
    }

    public boolean isInWorld() {
        return this.lastInWorld;
    }

}
