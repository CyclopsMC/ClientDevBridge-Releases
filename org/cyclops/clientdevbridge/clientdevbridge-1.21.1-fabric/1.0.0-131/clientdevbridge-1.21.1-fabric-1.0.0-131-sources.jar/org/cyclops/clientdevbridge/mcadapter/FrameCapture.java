package org.cyclops.clientdevbridge.mcadapter;

import org.cyclops.clientdevbridge.protocol.RpcException;

import javax.annotation.Nullable;
import net.minecraft.class_1011;
import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_318;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;

/**
 * Reads the main render target into a PNG.
 *
 * The capture itself must happen on the render thread while the GL context is current;
 * PNG encoding is pure CPU work on the resulting off-heap buffer, so it is done by the caller's
 * thread afterwards — the same split vanilla's own screenshot code uses.
 *
 * @author rubensworks
 */
public class FrameCapture {

    /**
     * A rectangle in pixel space.
     */
    public record Region(int x, int y, int width, int height) {
    }

    /**
     * The whole capture pipeline: grab the framebuffer, crop or rescale it, and PNG-encode it.
     *
     * This is a single adapter entry point on purpose. How a frame is read out of the GPU is one
     * of the most version-churning things in Minecraft — it has been a synchronous call, and it
     * has been a callback driven by a GPU buffer copy — so the handler must never see that shape.
     * It sees a future, on every branch.
     *
     * @param region the pixel-space rectangle to keep, or null for the whole frame
     * @param scale  a multiplier applied to the output size, or null for 1:1
     */
    public static CompletableFuture<Png> capture(@Nullable Region region, @Nullable Double scale) {
        // Hop a frame first, so the buffer read was rendered after the request arrived.
        return ClientThread.<class_1011>submitAfterFrame(() -> transform(grab(), region, scale))
                // PNG encoding is CPU work on an off-heap buffer, so it happens off the render thread.
                .thenApply(image -> {
                    int width = image.method_4307();
                    int height = image.method_4323();
                    return new Png(encodeAndClose(image), width, height);
                });
    }

    /**
     * An encoded frame.
     */
    public record Png(byte[] bytes, int width, int height) {
    }

    /**
     * Grabs the current framebuffer. Must be called on the render thread.
     */
    static class_1011 grab() {
        class_276 target = class_310.method_1551().method_1522();
        return class_318.method_1663(target);
    }

    /**
     * Crops and/or rescales a captured image, closing the source when a new image is produced.
     *
     * @param source the freshly grabbed frame
     * @param region the pixel-space rectangle to keep, or null for the whole frame
     * @param scale  a multiplier applied to the output size, or null for 1:1
     */
    static class_1011 transform(class_1011 source, @Nullable Region region, @Nullable Double scale) {
        int sourceWidth = source.method_4307();
        int sourceHeight = source.method_4323();

        int x = region == null ? 0 : region.x();
        int y = region == null ? 0 : region.y();
        int width = region == null ? sourceWidth : region.width();
        int height = region == null ? sourceHeight : region.height();

        if (width <= 0 || height <= 0) {
            source.close();
            throw RpcException.invalidParams("Region width and height must both be positive, but were "
                    + width + "x" + height);
        }
        if (x < 0 || y < 0 || x + width > sourceWidth || y + height > sourceHeight) {
            source.close();
            throw RpcException.invalidParams("Region " + x + "," + y + " " + width + "x" + height
                    + " does not fit inside the " + sourceWidth + "x" + sourceHeight + " framebuffer");
        }

        double effectiveScale = scale == null ? 1.0d : scale;
        if (effectiveScale <= 0 || effectiveScale > 8) {
            source.close();
            throw RpcException.invalidParams("Parameter 'scale' must be greater than 0 and at most 8, but was "
                    + effectiveScale);
        }

        int outputWidth = Math.max(1, (int) Math.round(width * effectiveScale));
        int outputHeight = Math.max(1, (int) Math.round(height * effectiveScale));

        boolean unchanged = x == 0 && y == 0 && width == sourceWidth && height == sourceHeight
                && outputWidth == sourceWidth && outputHeight == sourceHeight;
        if (unchanged) {
            return source;
        }

        class_1011 result = new class_1011(outputWidth, outputHeight, false);
        try {
            source.method_4300(x, y, width, height, result);
        } catch (Throwable e) {
            result.close();
            throw e;
        } finally {
            source.close();
        }
        return result;
    }

    /**
     * Encodes to PNG bytes and releases the image. Safe to call off the render thread.
     */
    static byte[] encodeAndClose(class_1011 image) {
        try {
            return image.method_24036();
        } catch (IOException e) {
            throw new RpcException(org.cyclops.clientdevbridge.protocol.RpcErrorCodes.INTERNAL_ERROR,
                    "Failed to PNG-encode the captured frame: " + e.getMessage());
        } finally {
            image.close();
        }
    }

}
