package org.cyclops.clientdevbridge.mcadapter;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_636;
import net.minecraft.class_746;
import net.minecraft.server.MinecraftServer;
import org.cyclops.clientdevbridge.protocol.RpcException;

/**
 * Right-clicking a block, the way a player does.
 *
 * The click goes through {@link class_636#method_2896}, so the block's own interaction
 * logic runs and whatever it does -- opening a screen, placing a part, consuming an item -- is
 * exactly what a player would get. Nothing is constructed out of band.
 *
 * @author rubensworks
 */
public class Interaction {

    /**
     * How much closer than the reach limit the player has to already be for the teleport to be
     * skipped. Sitting exactly on the limit would make the interaction depend on rounding.
     */
    private static final double REACH_MARGIN = 0.5d;

    /** How long to wait for the server to have the rotation the click depends on. */
    private static final int ROTATION_TIMEOUT_TICKS = 20;

    /**
     * The outcome of a click, in a vocabulary that is the same on every branch.
     *
     * {@code InteractionResult} is an enum on 1.21 and a sealed interface of records on 26, so its
     * own {@code toString} differs -- {@code SUCCESS} against
     * {@code Success[swingSource=CLIENT, ...]} -- and a caller checking for one would break on the
     * other. {@code consumesAction()} is the one predicate that reads identically on both, so the
     * report is built from it: SUCCESS when the block handled the click, PASS when it did not.
     *
     * The finer distinctions each version draws -- consume versus success, which arm swings, 1.21's
     * partial consume, 26's try-with-empty-hand -- are deliberately not surfaced. They cannot be
     * expressed identically across branches, and a protocol field that means something different
     * depending on which Minecraft answered is worse than one that says less.
     */
    public static String describeResult(class_1269 result) {
        return result.method_23665() ? "SUCCESS" : "PASS";
    }

    public static class_1269 useOn(Aim aim, class_1268 hand) {
        class_310 minecraft = class_310.method_1551();
        class_746 player = ClientState.requirePlayer();
        class_636 gameMode = minecraft.field_1761;
        if (gameMode == null) {
            throw RpcException.illegalState("There is no game mode yet; the world is still loading.");
        }
        double distance = player.method_33571().method_1022(aim.point());
        double reach = player.method_55754();
        if (distance > reach) {
            throw RpcException.illegalState(String.format(
                    "The aimed point on the block at %s is %.1f blocks away but the reach limit is "
                            + "%.1f. Teleport closer first, or leave 'approach' enabled.",
                    aim.pos().method_23854(), distance, reach));
        }
        return gameMode.method_2896(player, hand, aim.hit());
    }

    /**
     * Puts the player where the aim wants them and points them at it.
     *
     * When the player can already reach the block, nothing is teleported. That is not just an
     * optimisation: a teleport the player does not need is actively harmful, because the server
     * ignores interactions from a client it is still waiting on a teleport confirmation from. The
     * position hardly changes in that case, so waiting for the player to "arrive" returns
     * immediately, the click goes out during the confirmation window, and the server drops it
     * without a word.
     *
     * A directed aim always teleports, even from inside reach. Standing anywhere that can see the
     * block is enough for a vanilla block, but a multipart block resolves the click by casting a
     * ray from the eye, so the eye has to be on the right side of the face -- which the current
     * position generally is not.
     *
     * @return whether the player was teleported
     */
    public static boolean approach(Aim aim) {
        class_746 player = ClientState.requirePlayer();
        if (!aim.isDirected()
                && player.method_33571().method_1022(aim.point()) <= player.method_55754() - REACH_MARGIN) {
            aim(aim);
            return false;
        }
        double[] target = aim.standingPosition();
        float[] angles = aim.lookAngles();
        // The rotation goes into the teleport rather than being applied afterwards. /tp is what
        // makes the server's copy of the player authoritative, and a rotation applied on the
        // client during the teleport's round trip is computed from the position the player has
        // not left yet -- which aims at the block from wherever they were standing before.
        CommandRunner.run(String.format("tp @s %.3f %.3f %.3f %.2f %.2f",
                target[0], target[1], target[2], angles[0], angles[1]));
        return true;
    }

    /**
     * Points the player at the aim from wherever they are now.
     *
     * Called once the player has arrived, so {@link PlayerControl#lookAt} measures from the
     * position they actually ended up in -- the teleport puts them close to the target, not
     * exactly on it, because the server drops them onto the ground.
     */
    public static void aim(Aim aim) {
        PlayerControl.lookAt(aim.point());
    }

    /**
     * Whether the server's copy of the player is looking where the client is.
     *
     * A multipart block re-raytraces from the <em>server</em> player, and rotation only reaches the
     * server on the next movement packet -- so aiming and clicking in the same tick evaluates the
     * click against the previous rotation. Waiting for the server to agree is the same discipline
     * {@code approach} already applies to position, for the same underlying reason.
     *
     * A client with no integrated server cannot check, and reports true rather than blocking
     * forever; the caller's fixed wait covers that case.
     */
    public static boolean serverSeesRotation() {
        class_746 player = ClientState.requirePlayer();
        class_3222 serverPlayer = serverPlayer();
        if (serverPlayer == null) {
            return true;
        }
        return Math.abs(net.minecraft.class_3532.method_15381(serverPlayer.method_36454(), player.method_36454())) < 0.5f
                && Math.abs(serverPlayer.method_36455() - player.method_36455()) < 0.5f;
    }

    public static int rotationTimeoutTicks() {
        return ROTATION_TIMEOUT_TICKS;
    }

    /**
     * Holds or releases sneak, which some blocks read to pick a different interaction -- a wrench
     * removing a part rather than configuring it, for one.
     *
     * The server learns about it from its own packet, so a caller has to let a tick pass before
     * the click, exactly as with rotation.
     */
    public static void setSneaking(boolean sneaking) {
        class_746 player = ClientState.requirePlayer();
        player.method_5660(sneaking);
        player.field_3913.field_3903 = sneaking;
    }

    public static boolean isSneaking() {
        return ClientState.requirePlayer().method_5715();
    }

    /** What the player is holding, so a caller can see whether the click consumed anything. */
    public static String describeHeld(class_1268 hand) {
        class_1799 stack = ClientState.requirePlayer().method_5998(hand);
        return stack.method_7960()
                ? "empty"
                : net.minecraft.class_7923.field_41178.method_10221(stack.method_7909())
                        + " x" + stack.method_7947();
    }

    public static class_1268 hand(String name) {
        return "off".equals(name) ? class_1268.field_5810 : class_1268.field_5808;
    }

    private static class_3222 serverPlayer() {
        MinecraftServer server = class_310.method_1551().method_1576();
        if (server == null) {
            return null;
        }
        return server.method_3760().method_14602(ClientState.requirePlayer().method_5667());
    }

    /** Where {@link #approach(Aim)} puts the player, so the caller can wait for it to land there. */
    public static double[] approachTarget(Aim aim) {
        return aim.standingPosition();
    }

    private Interaction() {
    }

}
