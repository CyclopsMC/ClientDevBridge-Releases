package org.cyclops.clientdevbridge.mcadapter;

import org.cyclops.clientdevbridge.protocol.Json;
import org.cyclops.clientdevbridge.protocol.RpcException;

import com.google.gson.JsonObject;
import net.minecraft.class_1041;
import net.minecraft.class_310;

/**
 * Conversions between the two coordinate spaces the protocol uses.
 *
 * <ul>
 *     <li><b>GUI space</b>: Minecraft's scaled coordinates. All widget and screen positions are in
 *     GUI space, and it is the default for every input command.</li>
 *     <li><b>Pixel space</b>: raw framebuffer pixels, which is what screenshots are in.</li>
 * </ul>
 *
 * @author rubensworks
 */
public class Geometry {

    public static final String SPACE_GUI = "gui";
    public static final String SPACE_PIXEL = "pixel";

    public static class_1041 window() {
        return class_310.method_1551().method_22683();
    }

    /**
     * Converts an x/y from the given space into GUI space.
     */
    public static double toGui(double value, String space) {
        return SPACE_PIXEL.equals(space) ? value / window().method_4495() : value;
    }

    /**
     * Converts an x/y from the given space into pixel space.
     */
    public static double toPixel(double value, String space) {
        return SPACE_PIXEL.equals(space) ? value : value * window().method_4495();
    }

    public static String requireSpace(String space) {
        if (space == null) {
            return SPACE_GUI;
        }
        if (!SPACE_GUI.equals(space) && !SPACE_PIXEL.equals(space)) {
            throw RpcException.invalidParams("Parameter 'space' must be 'gui' or 'pixel', but was '" + space + "'");
        }
        return space;
    }

    /**
     * Rejects a point that is not on screen, in whichever space the caller used.
     *
     * Silently accepting one is the worst available answer: the command succeeds, nothing happens,
     * and the next screenshot is indistinguishable from a click that landed and did nothing. The
     * message quotes the caller's own numbers and the bounds in the caller's own space, because
     * being told that "9999,9999 is outside 427x240" when you asked in pixels is its own puzzle.
     *
     * @param x the x the caller gave, in {@code space}
     * @param y the y the caller gave, in {@code space}
     */
    public static void requireOnScreen(double x, double y, String space) {
        double width = SPACE_PIXEL.equals(space) ? window().method_4489() : guiWidth();
        double height = SPACE_PIXEL.equals(space) ? window().method_4506() : guiHeight();
        if (x < 0 || y < 0 || x > width || y > height) {
            throw RpcException.invalidParams(String.format(
                    "Point %.0f,%.0f is outside the screen, which is %.0fx%.0f in %s space. "
                            + "Take a fresh 'clientdevbridge snapshot': the coordinates it prints are "
                            + "in GUI space, and the window may have been resized since the last one.",
                    x, y, width, height, space));
        }
    }

    /** The GUI-space width of the screen, which is what every coordinate the bridge reports is in. */
    public static int guiWidth() {
        return window().method_4486();
    }

    public static int guiHeight() {
        return window().method_4502();
    }

    /**
     * The metrics block that every snapshot and screenshot result carries, so a caller can always
     * relate what it is looking at to the coordinates it should send back.
     */
    public static JsonObject metrics() {
        class_1041 window = window();
        JsonObject metrics = Json.object();
        metrics.addProperty("guiScale", window.method_4495());
        metrics.addProperty("guiWidth", window.method_4486());
        metrics.addProperty("guiHeight", window.method_4502());
        metrics.addProperty("pixelWidth", window.method_4489());
        metrics.addProperty("pixelHeight", window.method_4506());
        return metrics;
    }

    /**
     * Copies the standard metrics fields onto an existing result object.
     */
    public static void addMetrics(JsonObject target) {
        JsonObject metrics = metrics();
        for (String key : metrics.keySet()) {
            target.add(key, metrics.get(key));
        }
    }

}
