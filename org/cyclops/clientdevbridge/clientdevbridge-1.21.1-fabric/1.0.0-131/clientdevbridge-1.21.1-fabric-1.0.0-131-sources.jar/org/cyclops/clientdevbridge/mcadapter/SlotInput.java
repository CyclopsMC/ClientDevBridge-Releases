package org.cyclops.clientdevbridge.mcadapter;

import net.minecraft.class_1713;
import net.minecraft.class_310;
import org.cyclops.clientdevbridge.protocol.RpcException;

/**
 * The one version-sensitive step of a slot click: which enum names the operation, and which method
 * on the game mode performs it.
 *
 * Both moved in Minecraft 26 -- {@code ClickType} became {@code ContainerInput} and
 * {@code handleInventoryMouseClick} became {@code handleContainerInput} -- while everything around
 * the call did not. Keeping the pair here rather than in {@link InputControl} means the branches
 * differ in one small file instead of in the middle of a large shared one.
 *
 * @author rubensworks
 */
public class SlotInput {

    /**
     * Performs a click on a slot, given the protocol's name for what kind of click it is.
     *
     * The names are the protocol's, not the enum's: a caller should never have to know a Java
     * constant, and mapping them explicitly is also what keeps a rename from reaching the wire.
     */
    public static void perform(int containerId, int slotId, int button, String type) {
        class_310.method_1551().field_1761.method_2906(
                containerId, slotId, button, clickType(type), ClientState.requirePlayer());
    }

    private static class_1713 clickType(String name) {
        return switch (name) {
            case "pickup" -> class_1713.field_7790;
            case "quick_move" -> class_1713.field_7794;
            case "swap" -> class_1713.field_7791;
            case "clone" -> class_1713.field_7796;
            case "throw" -> class_1713.field_7795;
            case "quick_craft" -> class_1713.field_7789;
            case "pickup_all" -> class_1713.field_7793;
            default -> throw RpcException.invalidParams("Unknown click type '" + name + "'.");
        };
    }

}
