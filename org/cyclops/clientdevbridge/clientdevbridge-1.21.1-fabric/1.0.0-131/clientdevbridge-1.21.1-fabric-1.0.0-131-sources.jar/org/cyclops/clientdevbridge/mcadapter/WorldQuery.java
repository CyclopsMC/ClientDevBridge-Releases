package org.cyclops.clientdevbridge.mcadapter;

import com.google.gson.JsonObject;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_7923;
import org.cyclops.clientdevbridge.protocol.Json;
import org.cyclops.clientdevbridge.snapshot.BlockExtractors;

/**
 * Reading blocks out of the world.
 *
 * @author rubensworks
 */
public class WorldQuery {

    /**
     * A block entity's synced data as a string, or "" when there is none.
     *
     * Used to tell whether an interaction changed anything: for a multipart block the whole change
     * lives here, and comparing block ids and states says nothing at all.
     */
    public static String blockEntityData(class_2338 pos) {
        net.minecraft.class_2586 blockEntity =
                ClientState.requireLevel().method_8321(pos);
        if (blockEntity == null) {
            return "";
        }
        try {
            return blockEntity.method_38244(ClientState.requireLevel().method_30349()).toString();
        } catch (Throwable e) {
            // A block entity that refuses to serialise should not fail the interaction that only
            // wanted to know whether it had changed.
            return "";
        }
    }

    public static JsonObject block(class_2338 pos, boolean includeNbt) {
        class_2680 state = ClientState.requireLevel().method_8320(pos);

        JsonObject result = Json.object();
        result.addProperty("block", class_7923.field_41175.method_10221(state.method_26204()).toString());
        result.add("pos", Json.arrayOfNumbers(pos.method_10263(), pos.method_10264(), pos.method_10260()));
        result.addProperty("state", state.toString());

        JsonObject properties = Json.object();
        for (class_2769<?> property : state.method_28501()) {
            properties.addProperty(property.method_11899(), describe(state, property));
        }
        result.add("properties", properties);

        class_2586 blockEntity = ClientState.requireLevel().method_8321(pos);
        if (blockEntity == null) {
            result.add("blockEntity", com.google.gson.JsonNull.INSTANCE);
        } else {
            JsonObject entityObject = Json.object();
            entityObject.addProperty("type", class_7923.field_41181
                    .method_10221(blockEntity.method_11017()).toString());
            // What distinguishes one instance of this block entity from another, if the mod that
            // owns it said. Without this a cable with a part on it and a bare one describe
            // identically, so an agent cannot check its own setup.
            JsonObject details = Json.object();
            BlockExtractors.apply(blockEntity, details);
            if (!details.isEmpty()) {
                entityObject.add("details", details);
            }
            if (includeNbt) {
                // The client only has whatever the server chose to sync, which for most block
                // entities is the update tag rather than the full save data.
                entityObject.addProperty("nbt", blockEntity
                        .method_38244(ClientState.requireLevel().method_30349()).toString());
            }
            result.add("blockEntity", entityObject);
        }
        return result;
    }

    private static <T extends Comparable<T>> String describe(class_2680 state, class_2769<T> property) {
        return property.method_11901(state.method_11654(property));
    }

}
