package org.cyclops.clientdevbridge.mcadapter;

import net.minecraft.class_342;
import net.minecraft.class_344;
import net.minecraft.class_350;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_5676;
import net.minecraft.class_7528;
import net.minecraft.class_7842;
import net.minecraft.class_7919;
import net.minecraft.class_7940;
import net.minecraft.class_8089;
import org.cyclops.clientdevbridge.snapshot.SnapshotExtractors;

/**
 * Snapshot detail for the vanilla widget types.
 *
 * The exact set of classes differs between Minecraft versions, which is why this lives in
 * {@code mcadapter} — the registry and the node model it feeds do not change.
 *
 * @author rubensworks
 */
public class VanillaExtractors {

    public static void registerAll() {
        SnapshotExtractors.register(class_4185.class, (button, node) ->
                node.extra("kind", "button"));

        SnapshotExtractors.register(class_344.class, (button, node) ->
                node.extra("kind", "imageButton"));

        SnapshotExtractors.register(class_342.class, (editBox, node) -> {
            node.value(editBox.method_1882());
            node.extra("kind", "editBox");
            node.extra("editable", editBox.method_37303());
        });

        SnapshotExtractors.register(class_4286.class, (checkbox, node) -> {
            node.value(checkbox.method_20372());
            node.extra("kind", "checkbox");
        });

        SnapshotExtractors.register(class_5676.class, (cycleButton, node) -> {
            Object value = cycleButton.method_32603();
            node.value(value == null ? null : String.valueOf(value));
            node.extra("kind", "cycleButton");
        });

        SnapshotExtractors.register(class_357.class, (slider, node) -> {
            // Normalised 0..1, which is the only representation the base class exposes; a subclass
            // knows how to map it onto its own units, but the snapshot deliberately does not guess.
            node.value(slider.field_22753);
            node.extra("kind", "slider");
        });

        SnapshotExtractors.register(class_350.class, (list, node) -> {
            node.extra("kind", "selectionList");
            node.extra("entryCount", list.method_25396().size());
            node.extra("rowWidth", list.method_25322());
            node.extra("scrollAmount", list.method_25341());
            node.extra("maxScroll", list.method_25331());
            Object selected = list.method_25334();
            node.extra("selected", selected == null ? null : String.valueOf(selected));
        });

        SnapshotExtractors.register(class_7528.class, (widget, node) -> {
            node.extra("kind", "scrollWidget");
            node.extra("scrollbarWidth", widget.method_53532());
        });

        SnapshotExtractors.register(class_7842.class, (widget, node) ->
                node.extra("kind", "text"));

        SnapshotExtractors.register(class_7940.class, (widget, node) ->
                node.extra("kind", "multiLineText"));

        SnapshotExtractors.register(class_8089.class, (bar, node) ->
                node.extra("kind", "tabNavigation"));

        // Widget tooltips are attached rather than rendered inline, so they would otherwise be
        // invisible to a snapshot even though they are exactly what a caller is looking for.
        SnapshotExtractors.register(net.minecraft.class_339.class, (widget, node) -> {
            class_7919 tooltip = widget.method_51254();
            if (tooltip != null) {
                node.extra("tooltip", TooltipCapture.describe(tooltip));
            }
        });
    }

}
