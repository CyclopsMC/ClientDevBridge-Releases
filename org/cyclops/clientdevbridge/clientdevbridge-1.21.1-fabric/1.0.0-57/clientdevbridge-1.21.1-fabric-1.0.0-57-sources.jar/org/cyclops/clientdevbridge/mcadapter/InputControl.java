package org.cyclops.clientdevbridge.mcadapter;

import org.cyclops.clientdevbridge.protocol.RpcException;

import javax.annotation.Nullable;
import net.minecraft.class_1041;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_437;

/**
 * Delivers synthetic input.
 *
 * Input goes to the open {@link class_437} through the same {@code GuiEventListener} methods GLFW
 * callbacks use, so widgets see exactly what a real click would produce. With no screen open the
 * input is in-world instead, and has to go through {@link class_304} — there is no listener to
 * deliver a raw key event to.
 *
 * All coordinates arriving here are already in GUI space; {@link Geometry} does the conversion.
 *
 * @author rubensworks
 */
public class InputControl {

    /**
     * Where the pointer is, in GUI space, read from the game rather than remembered.
     *
     * This used to return the last position the bridge itself asked for, defaulting to 0,0. On a
     * virtual display the real pointer starts at the centre of the window, so before any
     * mouse-move a snapshot reported "mouse at 0,0" and, in the same breath, marked the centre
     * slot hovered -- two true-looking statements that contradict each other, and the screenshot
     * sided with the game.
     */
    public static double getMouseX() {
        class_1041 window = class_310.method_1551().method_22683();
        return class_310.method_1551().field_1729.field_1795
                * window.method_4486() / (double) window.method_4480();
    }

    public static double getMouseY() {
        class_1041 window = class_310.method_1551().method_22683();
        return class_310.method_1551().field_1729.field_1794
                * window.method_4502() / (double) window.method_4507();
    }

    public static void mouseMove(double x, double y) {
        // Minecraft recomputes hover state every frame from MouseHandler's own position, so it has
        // to be written directly. Asking GLFW to move the cursor does not work: it is ignored while
        // the window is not focused, which it never is under a virtual display. Without this the
        // hovered slot, the hover highlight and any rendered tooltip keep tracking wherever the
        // pointer physically is, and a screenshot shows that rather than what was asked for.
        class_310 minecraft = class_310.method_1551();
        class_1041 window = minecraft.method_22683();
        minecraft.field_1729.field_1795 = x * (double) window.method_4480() / window.method_4486();
        minecraft.field_1729.field_1794 = y * (double) window.method_4507() / window.method_4502();

        class_437 screen = ClientState.screen();
        if (screen != null) {
            screen.method_16014(x, y);
        }
    }

    public static void mouseClick(double x, double y, int button) {
        class_437 screen = ClientState.screen();
        if (screen == null) {
            // No screen: a click is an in-world attack (0) or use (1).
            class_304 mapping = button == 0
                    ? class_310.method_1551().field_1690.field_1886
                    : class_310.method_1551().field_1690.field_1904;
            class_304.method_1420(mapping.method_1429());
            return;
        }
        mouseMove(x, y);
        screen.method_25402(x, y, button);
        screen.method_25406(x, y, button);
    }

    public static void mouseDrag(double fromX, double fromY, double toX, double toY, int button, int steps) {
        class_437 screen = requireScreenFor("dragging");
        if (steps < 1) {
            throw RpcException.invalidParams("Parameter 'steps' must be at least 1, but was " + steps);
        }
        mouseMove(fromX, fromY);
        screen.method_25402(fromX, fromY, button);

        double previousX = fromX;
        double previousY = fromY;
        for (int step = 1; step <= steps; step++) {
            double progress = (double) step / steps;
            double x = fromX + (toX - fromX) * progress;
            double y = fromY + (toY - fromY) * progress;
            screen.method_25403(x, y, button, x - previousX, y - previousY);
            previousX = x;
            previousY = y;
        }

        mouseMove(toX, toY);
        screen.method_25406(toX, toY, button);
    }

    public static void scroll(double x, double y, double deltaX, double deltaY) {
        class_437 screen = requireScreenFor("scrolling");
        mouseMove(x, y);
        screen.method_25401(x, y, deltaX, deltaY);
    }

    /**
     * @param action one of {@code press}, {@code release} or {@code tap}
     */
    public static void key(int keyCode, String action, int modifiers) {
        class_437 screen = ClientState.screen();
        if (screen != null) {
            switch (action) {
                case "press" -> screen.method_25404(keyCode, -1, modifiers);
                case "release" -> screen.method_16803(keyCode, -1, modifiers);
                default -> {
                    screen.method_25404(keyCode, -1, modifiers);
                    screen.method_16803(keyCode, -1, modifiers);
                }
            }
            return;
        }

        class_304 mapping = Keys.findMapping(keyCode);
        if (mapping == null) {
            throw RpcException.illegalState("No screen is open and no key binding matches key code " + keyCode
                    + ", so there is nothing to deliver the key press to.");
        }
        class_3675.class_306 key = mapping.method_1429();
        switch (action) {
            case "press" -> class_304.method_1416(key, true);
            case "release" -> class_304.method_1416(key, false);
            default -> class_304.method_1420(key);
        }
    }

    /**
     * Holds a key down. Release is the caller's job, after the ticks it wants have elapsed.
     */
    public static void setKeyHeld(int keyCode, boolean held) {
        class_304 mapping = Keys.findMapping(keyCode);
        if (mapping == null) {
            throw RpcException.illegalState("No key binding matches key code " + keyCode
                    + ", so it cannot be held. Held keys are for movement and other bound actions.");
        }
        class_304.method_1416(mapping.method_1429(), held);
    }

    public static void type(String text) {
        class_437 screen = requireScreenFor("typing");
        text.codePoints().forEach(codePoint -> {
            for (char character : Character.toChars(codePoint)) {
                screen.method_25400(character, 0);
            }
        });
    }

    private static class_437 requireScreenFor(String what) {
        class_437 screen = ClientState.screen();
        if (screen == null) {
            throw RpcException.illegalState("No screen is open, so there is nothing to deliver " + what + " to. "
                    + "Open one with 'open-gui' first.");
        }
        return screen;
    }

    /**
     * Releases every held key. Called when a world is left, so a held movement key cannot leak
     * into the next scenario.
     */
    public static void releaseAll() {
        class_304.method_1437();
    }

    @Nullable
    static class_437 currentScreen() {
        return ClientState.screen();
    }

}
