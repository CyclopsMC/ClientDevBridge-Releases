package org.cyclops.clientdevbridge.mcadapter;

import net.minecraft.class_1268;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * Opening and closing screens.
 *
 * Opening a block's GUI is a real right-click, so the block's own interaction logic runs and the
 * resulting screen is the one a player would get -- not a screen constructed out of band, which
 * would skip whatever the mod does on interaction. {@link Interaction} does the clicking; what is
 * left here is the screen itself, and explaining a click that opened nothing.
 *
 * @author rubensworks
 */
public class ScreenControl {

    public static void close() {
        class_310.method_1551().method_1507(null);
    }

    public static void openBlock(Aim aim) {
        Interaction.useOn(aim, class_1268.field_5808);
    }

    /**
     * Explains why nothing opened, with the numbers needed to tell the cases apart.
     *
     * The aim is named whenever one was given, because on a multipart block it is the likeliest
     * thing to have been wrong: the click landed, and it landed somewhere else on the block.
     */
    public static String describeFailedOpen(Aim aim) {
        class_746 player = ClientState.requirePlayer();
        double distance = player.method_33571().method_1022(aim.point());
        String block = net.minecraft.class_7923.field_41175
                .method_10221(ClientState.requireLevel().method_8320(aim.pos()).method_26204()).toString();
        if (distance > player.method_55754()) {
            return String.format(
                    "Right-clicking %s at %s opened no screen. The player ended up %.1f blocks "
                            + "away, past the %.1f reach limit, so the server rejected the click.",
                    block, aim.pos().method_23854(), distance, player.method_55754());
        }
        return String.format(
                "Right-clicking %s at %s (aimed at the %s side) opened no screen. The player is "
                        + "%.1f blocks away, inside the %.1f reach limit, so the click was "
                        + "delivered and nothing opened. Either the block has no GUI, or it has "
                        + "one per side -- a cable's parts, say -- and this side has none. "
                        + "'clientdevbridge block %d %d %d --nbt' shows what is actually there; "
                        + "--face picks a different side.",
                block, aim.pos().method_23854(), aim.face().method_10151(), distance,
                player.method_55754(), aim.pos().method_10263(), aim.pos().method_10264(), aim.pos().method_10260());
    }

}
