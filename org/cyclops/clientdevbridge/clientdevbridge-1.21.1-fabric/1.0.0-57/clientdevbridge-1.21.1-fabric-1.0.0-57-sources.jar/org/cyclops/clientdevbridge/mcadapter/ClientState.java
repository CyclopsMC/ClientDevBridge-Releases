package org.cyclops.clientdevbridge.mcadapter;

import com.google.gson.JsonObject;
import org.cyclops.clientdevbridge.protocol.Json;
import org.cyclops.clientdevbridge.protocol.RpcException;

import javax.annotation.Nullable;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * Read-only views of the client's current state.
 *
 * Everything here reaches into {@code net.minecraft} and is therefore expected to need
 * attention when porting to a new Minecraft version; handlers only ever see the JSON it produces.
 *
 * @author rubensworks
 */
public class ClientState {

    /**
     * The OpenGL renderer string, e.g. {@code llvmpipe (LLVM 20.1.2, 256 bits)}.
     */
    public static String glRenderer() {
        try {
            return net.minecraft.class_4494.method_22090();
        } catch (Throwable e) {
            // Only reachable off the render thread or before the context exists; not worth failing over.
            return "unknown";
        }
    }

    /**
     * The running Minecraft version, e.g. {@code 1.21.1}.
     */
    public static String minecraftVersion() {
        return net.minecraft.class_155.method_16673().method_48019();
    }

    /**
     * The registry access the client currently has, needed to serialise {@code Component}s.
     * Falls back to the built-in registries before a world is joined.
     */
    public static net.minecraft.class_7225.class_7874 registryAccess() {
        net.minecraft.class_638 level = class_310.method_1551().field_1687;
        return level == null
                ? net.minecraft.class_5455.method_40302(
                        net.minecraft.class_7923.field_41167)
                : level.method_30349();
    }

    @Nullable
    public static class_437 screen() {
        return class_310.method_1551().field_1755;
    }

    @Nullable
    public static String screenClass() {
        class_437 screen = screen();
        return screen == null ? null : screen.getClass().getName();
    }

    /**
     * Whether the client has finished starting up.
     *
     * The bridge's socket opens during mod initialisation, which is well before the game is
     * usable: the resource reload is still running behind a {@code LoadingOverlay}, no client
     * ticks are happening, and anything asked of the game will either race or hang. This is the
     * signal that the client is genuinely ready to be driven.
     */
    public static boolean isLoaded() {
        class_310 minecraft = class_310.method_1551();
        return minecraft.method_18506() == null && minecraft.field_1755 != null || inWorld();
    }

    public static boolean inWorld() {
        class_310 minecraft = class_310.method_1551();
        return minecraft.field_1687 != null && minecraft.field_1724 != null;
    }

    /**
     * @return the player, failing with a clear message when there is no world loaded
     */
    public static class_746 requirePlayer() {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null) {
            throw RpcException.illegalState(
                    "Not in a world. Run 'clientdevbridge world-reset' or 'world-load <name>' first.");
        }
        return player;
    }

    public static class_638 requireLevel() {
        class_638 level = class_310.method_1551().field_1687;
        if (level == null) {
            throw RpcException.illegalState(
                    "Not in a world. Run 'clientdevbridge world-reset' or 'world-load <name>' first.");
        }
        return level;
    }

    public static class_437 requireScreen() {
        class_437 screen = screen();
        if (screen == null) {
            throw RpcException.illegalState("No screen is open. Open one with 'open-gui' or press a key first.");
        }
        return screen;
    }

    /**
     * Whether the chunk containing a position is loaded on the client.
     */
    public static boolean isChunkLoaded(int x, int y, int z) {
        class_310 minecraft = class_310.method_1551();
        return minecraft.field_1687 != null && minecraft.field_1687.method_8477(new net.minecraft.class_2338(x, y, z));
    }

    /**
     * A class loader that can see Minecraft's own dependencies, which is where the {@code eval}
     * escape hatch has to look for a script engine.
     */
    public static ClassLoader vanillaClassLoader() {
        return class_310.class.getClassLoader();
    }

    /**
     * Whether a world is not merely joined but ready to be looked at: the integrated server is up,
     * the loading screen is gone, and the given position is in a loaded chunk.
     *
     * All three matter to a screenshot. A client that has joined but is still showing "Loading
     * terrain" renders something, and it is not the world.
     */
    public static boolean isWorldReadyAt(int x, int y, int z) {
        class_310 minecraft = class_310.method_1551();
        return inWorld()
                && minecraft.method_1576() != null
                && screen() == null
                && minecraft.field_1687 != null
                && minecraft.field_1687.method_8477(new net.minecraft.class_2338(x, y, z));
    }

    /**
     * The vanilla objects the {@code eval} escape hatch exposes to a script.
     *
     * They live here rather than in the handler because they are vanilla types, and every one of
     * them has been reached through a different accessor at some point in Minecraft's history.
     */
    public static java.util.Map<String, Object> scriptBindings() {
        class_310 minecraft = class_310.method_1551();
        java.util.Map<String, Object> bindings = new java.util.LinkedHashMap<>();
        bindings.put("mc", minecraft);
        bindings.put("player", minecraft.field_1724);
        bindings.put("level", minecraft.field_1687);
        bindings.put("screen", screen());
        bindings.put("window", minecraft.method_22683());
        bindings.put("server", minecraft.method_1576());
        return bindings;
    }

    /**
     * The {@code status} result: cheap enough to poll constantly.
     */
    public static JsonObject status(long tick) {
        class_310 minecraft = class_310.method_1551();
        JsonObject status = Json.object();
        status.addProperty("loaded", isLoaded());
        status.addProperty("inWorld", inWorld());
        status.addProperty("screenClass", screenClass());
        status.addProperty("tick", tick);
        status.addProperty("fps", minecraft.method_47599());
        // The run directory the game actually chose. Which one that is depends on the Gradle
        // plugin, not on the loader, so the CLI cannot know it up front: it pins the determinism
        // options into its best guess before launch and corrects itself against this afterwards.
        status.addProperty("gameDir", minecraft.field_1697.toPath().toAbsolutePath().normalize().toString());

        class_638 level = minecraft.field_1687;
        status.addProperty("dimension", level == null ? null : level.method_27983().method_29177().toString());

        class_746 player = minecraft.field_1724;
        if (player == null) {
            status.add("player", com.google.gson.JsonNull.INSTANCE);
        } else {
            JsonObject playerObject = Json.object();
            playerObject.add("pos", Json.arrayOfNumbers(player.method_23317(), player.method_23318(), player.method_23321()));
            playerObject.addProperty("yaw", player.method_36454());
            playerObject.addProperty("pitch", player.method_36455());
            status.add("player", playerObject);
        }

        // The renderer name is what keys golden-image sets: llvmpipe and a real GPU do not
        // produce identical pixels, and one tolerance cannot cover both without hiding regressions.
        status.addProperty("glRenderer", glRenderer());

        Geometry.addMetrics(status);
        return status;
    }

}
